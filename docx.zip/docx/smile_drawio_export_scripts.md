# Draw.io Import & Integration Scripts: SMILE Portal
> [!TIP]
> This document contains copy-pasteable script blocks that you can import directly into **Draw.io** (`https://draw.io` or `https://app.diagrams.net`) or **Lucidchart** (`https://lucid.co`) to instantly generate your UML Diagrams, ERD diagrams, and flowcharts. No manual box-drawing required!

---

## Method 1: Generate your ERD Instantly using SQL (Highly Recommended)
Draw.io and Lucidchart have a built-in feature that reads raw SQL `CREATE TABLE` scripts and turns them into fully formed, professional ERD diagrams.

### How to use in Draw.io:
1. Open a blank diagram in **Draw.io**.
2. Go to the top menu and select **Arrange** -> **Insert** -> **Advanced** -> **SQL...**
3. Select and copy the entire SQL script block below.
4. Paste it into the Draw.io SQL text area and click **Insert**.
5. Draw.io will instantly generate all tables with their fields, types, and primary keys. You just have to drag the connector lines between them!

### How to use in Lucidchart (Luci):
1. Open a blank document in **Lucidchart**.
2. Press the **M** key (or click "More Shapes" in the bottom left).
3. Search for **"Entity Relationship"**, check it, and click **"Use Selected Shapes"**.
4. In the left panel under "Entity Relationship", click the **"Import"** button.
5. Choose **"MS SQL Server"** as the DBMS and click **Next**.
6. Paste the SQL code block below into the import area and click **Import**.

### Copy this SQL DDL Code:
```sql
CREATE TABLE Admin (
    AdminID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    AdminName VARCHAR(100) NOT NULL,
    AdminEmail VARCHAR(255) NOT NULL UNIQUE,
    AdminPassword VARCHAR(255) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE Organisation (
    OrgId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    OrgName VARCHAR(255) NOT NULL,
    OrgEmail VARCHAR(255) NOT NULL,
    Type VARCHAR(255) NOT NULL,
    Province VARCHAR(255) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Status VARCHAR(20) NOT NULL CHECK (Status IN ('Rejected', 'Active', 'Pending')),
    DateCreated DATETIME DEFAULT GETDATE()
);

CREATE TABLE Student (
    StuID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    StuName VARCHAR(255) NOT NULL,
    StuLastName VARCHAR(255) NOT NULL,
    StuEmail VARCHAR(255) NOT NULL,
    StuProvince VARCHAR(255) NOT NULL,
    StuEducationLevel VARCHAR(255) NOT NULL,
    StuPassword VARCHAR(255) NOT NULL,
    StuBio NVARCHAR(MAX) NULL,
    ProfilePicUrl NVARCHAR(255) NULL,
    DateCreated DATETIME DEFAULT GETDATE()
);

CREATE TABLE Opportunities (
    OppID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    OrgId INT NOT NULL,
    Title VARCHAR(120) NOT NULL,
    OppType VARCHAR(50) NOT NULL,
    Province VARCHAR(50) NOT NULL,
    Description VARCHAR(MAX) NOT NULL,
    Requirements VARCHAR(MAX) NULL,
    ApplicationLink VARCHAR(255) NULL,
    MaxApplicants INT NULL,
    ApplicationDeadline DATE NOT NULL,
    StartDate DATE NULL,
    Status VARCHAR(20) DEFAULT 'Active',
    Lat DECIMAL(9, 6) NULL,
    Lng DECIMAL(9, 6) NULL,
    DateCreated DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (OrgId) REFERENCES Organisation(OrgId) ON DELETE CASCADE
);

CREATE TABLE Applications (
    AppID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    OppID INT NOT NULL,
    StuID INT NOT NULL,
    Status VARCHAR(20) DEFAULT 'Pending',
    DateApplied DATETIME DEFAULT GETDATE(),
    UNIQUE (OppID, StuID),
    FOREIGN KEY (OppID) REFERENCES Opportunities(OppID) ON DELETE CASCADE,
    FOREIGN KEY (StuID) REFERENCES Student(StuID) ON DELETE CASCADE
);

CREATE TABLE Feedback (
    FeedbackID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    OppID INT NOT NULL,
    StuID INT NOT NULL,
    Rating INT CHECK (Rating >= 1 AND Rating <= 5),
    Comment VARCHAR(MAX) NULL,
    DateSubmitted DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (OppID) REFERENCES Opportunities(OppID) ON DELETE CASCADE,
    FOREIGN KEY (StuID) REFERENCES Student(StuID) ON DELETE CASCADE
);

CREATE TABLE StudentInterests (
    InterestID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    StuID INT NOT NULL UNIQUE,
    Realistic INT DEFAULT 0,
    Investigative INT DEFAULT 0,
    Artistic INT DEFAULT 0,
    Social INT DEFAULT 0,
    Enterprising INT DEFAULT 0,
    Conventional INT DEFAULT 0,
    TopInterest VARCHAR(50) NULL,
    DateTaken DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (StuID) REFERENCES Student(StuID) ON DELETE CASCADE
);

CREATE TABLE SavedCareerDocs (
    DocID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    StuID INT NULL,
    CareerTitle VARCHAR(100) NULL,
    DocContent NVARCHAR(MAX) NULL,
    DateSaved DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (StuID) REFERENCES Student(StuID) ON DELETE CASCADE
);

CREATE TABLE SavedOpportunities (
    SaveID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    StuID INT NOT NULL,
    OppID INT NOT NULL,
    DateSaved DATETIME DEFAULT GETDATE(),
    UNIQUE (StuID, OppID),
    FOREIGN KEY (StuID) REFERENCES Student(StuID) ON DELETE CASCADE,
    FOREIGN KEY (OppID) REFERENCES Opportunities(OppID) ON DELETE CASCADE
);

CREATE TABLE SupportTickets (
    TicketID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    SubmitterID INT NOT NULL,
    SubmitterType VARCHAR(10) NOT NULL CHECK (SubmitterType IN ('student', 'org')),
    TicketType VARCHAR(30) NOT NULL,
    Subject VARCHAR(255) NOT NULL,
    Description NVARCHAR(MAX) NOT NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'Open' CHECK (Status IN ('Open', 'Resolved')),
    AdminFeedback NVARCHAR(MAX) NULL,
    DateCreated DATETIME NOT NULL DEFAULT GETDATE(),
    DateResolved DATETIME NULL
);
```

---

## Method 2: Insert Diagrams via Mermaid.js Scripts
Draw.io and Lucidchart both support **Mermaid.js** code to auto-generate diagram visual models.

### How to use in Draw.io:
1. Open Draw.io $\rightarrow$ **Arrange** -> **Insert** -> **Advanced** -> **Mermaid...**
2. Paste either code block below and click **Insert**.

### How to use in Lucidchart (Luci):
1. Open Lucidchart $\rightarrow$ Enable **"Diagram as Code"** library (from the `+` More Shapes menu).
2. Click **+ New Mermaid diagram** in the panel.
3. Paste either code block below and click **Generate**.

### A. Use Case Diagram (Actors & Interactions)
```mermaid
graph TB
    %% Actors
    Stu[Student / Youth]
    Org[Organisation / NGO]
    Adm[Administrator]
    Ext[External APIs & AI]

    %% System Boundary
    subgraph SMILE_System_Boundary["SMILE System Boundary"]
        UC1(Register / Login Account)
        UC2(Browse & Bookmark/Save Opportunities)
        UC3(Apply for Volunteering/Training)
        UC4(View Opportunities Near Me on Map)
        UC5(Take Holland Code Interest Test)
        UC6(Chat with AI Career Coach)
        UC7(Create & Manage Opportunities)
        UC8(Manage Applicants & Process status)
        UC9(View Performance Analytics Dashboard)
        UC10(Verify & Onboard Organisations)
        UC11(Moderate Student Accounts)
        UC12(Submit Support Tickets / Bug Reports)
        UC13(Resolve Support Tickets + Admin Feedback)
    end

    %% Student Relationships
    Stu --> UC1
    Stu --> UC2
    Stu --> UC3
    Stu --> UC4
    Stu --> UC5
    Stu --> UC6
    Stu --> UC12

    %% Organisation Relationships
    Org --> UC1
    Org --> UC7
    Org --> UC8
    Org --> UC9
    Org --> UC12

    %% Admin Relationships
    Adm --> UC1
    Adm --> UC10
    Adm --> UC11
    Adm --> UC13

    %% External Connections
    UC4 -.-> Ext
    UC6 -.-> Ext
```

### B. Entity-Relationship Diagram (ERD Syntax)
```mermaid
erDiagram
    Organisation ||--o{ Opportunities : "creates (1:N)"
    Student ||--o{ Applications : "submits (1:N)"
    Student ||--o{ Feedback : "writes (1:N)"
    Student ||--o| StudentInterests : "takes (1:1)"
    Student ||--o{ SavedCareerDocs : "saves (1:N)"
    Student ||--o{ SavedOpportunities : "bookmarks (1:M)"
    Opportunities ||--o{ SavedOpportunities : "bookmarked_in (1:M)"
    Student ||--o{ SupportTickets : "submits (1:N)"
    Organisation ||--o{ SupportTickets : "submits (1:N)"
    Opportunities ||--o{ Applications : "has (1:N)"
    Opportunities ||--o{ Feedback : "receives (1:N)"

    Admin {
        int AdminID PK
        varchar AdminName
        varchar AdminEmail
        varchar AdminPassword
        datetime CreatedAt
    }
    Organisation {
        int OrgId PK
        varchar OrgName
        varchar OrgEmail
        varchar Type
        varchar Province
        varchar Status
    }
    Student {
        int StuID PK
        varchar StuName
        varchar StuLastName
        varchar StuEmail
        varchar StuProvince
        varchar StuEducationLevel
    }
    Opportunities {
        int OppID PK
        int OrgId FK
        varchar Title
        varchar OppType
        varchar Province
        varchar Description
        decimal Lat
        decimal Lng
    }
    Applications {
        int AppID PK
        int OppID FK
        int StuID FK
        varchar Status
        datetime DateApplied
    }
    Feedback {
        int FeedbackID PK
        int OppID FK
        int StuID FK
        int Rating
        varchar Comment
    }
    StudentInterests {
        int InterestID PK
        int StuID FK
        int Realistic
        int Investigative
        int Artistic
        int Social
        int Enterprising
        int Conventional
        varchar TopInterest
    }
    SavedCareerDocs {
        int DocID PK
        int StuID FK
        varchar CareerTitle
        nvarchar DocContent
    }
    SavedOpportunities {
        int SaveID PK
        int StuID FK
        int OppID FK
        datetime DateSaved
    }
    SupportTickets {
        int TicketID PK
        int SubmitterID
        varchar SubmitterType
        varchar TicketType
        varchar Subject
        nvarchar Description
        varchar Status
        nvarchar AdminFeedback
        datetime DateCreated
        datetime DateResolved
    }
```

---

## Method 3: Insert Diagrams via PlantUML Scripts

In Draw.io, you can also import via **Arrange** -> **Insert** -> **Advanced** -> **PlantUML...** and pasting the block below.

### PlantUML Use Case Diagram Code:
```plantuml
@startuml
left to right direction
skinparam packageStyle rect

actor "Student (Youth)" as Student
actor "Organisation" as Org
actor "Administrator" as Admin
actor "External Systems (Maps, Groq AI)" as External

rectangle "SMILE Portal" {
  usecase "Register & Authenticate" as UC1
  usecase "Browse & Save/Bookmark Opportunities" as UC2
  usecase "Apply for Opportunity" as UC3
  usecase "View Near Me Map" as UC4
  usecase "Take RIASEC Interest Quiz" as UC5
  usecase "Consult AI Career Coach" as UC6
  
  usecase "Post & Edit Opportunities" as UC7
  usecase "Approve/Reject Candidates" as UC8
  usecase "Inspect Recruitment Analytics" as UC9
  
  usecase "Approve/Suspend Organisations" as UC10
  usecase "Moderate System Accounts" as UC11
  usecase "Submit Support Tickets" as UC12
  usecase "Resolve Support Tickets" as UC13
}

Student --> UC1
Student --> UC2
Student --> UC3
Student --> UC4
Student --> UC5
Student --> UC6
Student --> UC12

Org --> UC1
Org --> UC7
Org --> UC8
Org --> UC9
Org --> UC12

Admin --> UC1
Admin --> UC10
Admin --> UC11
Admin --> UC13

UC4 --> External
UC6 --> External
@endum
```
