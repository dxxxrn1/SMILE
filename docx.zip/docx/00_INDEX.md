# SMILE Documentation Index

## How to Use These Documents

All documentation files are located in `d:\htmlProjects\SMILE-1\docx\`

---

## Document Registry

| # | File | Contents |
|---|---|---|
| 01 | [01_system_architecture_uml.md](./01_system_architecture_uml.md) | System Architecture UML (3-Tier), draw.io XML |
| 02 | [02_use_case_diagram.md](./02_use_case_diagram.md) | Use Case Diagram + 6 detailed use case descriptions |
| 03 | [03_erd_diagram.md](./03_erd_diagram.md) | Full ERD with all 9 tables, relationships, constraints |
| 04 | [04_actor_diagrams.md](./04_actor_diagrams.md) | Actor diagrams (2 variants), responsibility matrix |
| 05 | [05_full_project_documentation.md](./05_full_project_documentation.md) | Complete project doc (SDLC + DBLC + API + Security) |
| 06 | [06_inline_svg_icons.md](./06_inline_svg_icons.md) | UI icon system — inline SVG pattern, no icon libraries |
| 07 | [security.test.js](./security.test.js) | Automated security auditing and verification test suite |

---

## How to Import into draw.io

1. Open **draw.io** (app.diagrams.net or desktop app)
2. Create a new diagram
3. Go to **Extras → Edit Diagram** (Ctrl+Shift+X)
4. **Select all** existing XML and delete it
5. **Copy and paste** the XML from any of the documents above
6. Click **OK**

> The XML in each document is clearly labelled under `## ... draw.io XML`

---

## Diagrams Available for draw.io

| Diagram | File | Description |
|---|---|---|
| System Architecture | `01_system_architecture_uml.md` | 3-tier architecture with all components |
| Use Case Diagram | `02_use_case_diagram.md` | All 26 use cases with actor associations |
| ERD (Entity Relationship) | `03_erd_diagram.md` | All 9 tables with columns, PKs, FKs, relationships |
| Actor Overview | `04_actor_diagrams.md` | All actors with permissions boxes |
| Actor Hierarchy | `04_actor_diagrams.md` | JWT auth flow and role hierarchy |

---

## SDLC & DBLC Sections (in doc 05)

| Section | Location in 05_full_project_documentation.md |
|---|---|
| SDLC (7 phases) | Section 10 |
| Database Life Cycle (8 stages) | Section 11 |
| API Reference (all routes) | Section 6 |
| Authentication & Security | Section 7 |
| External Integrations | Section 8 |
| Feature Modules | Section 9 |
| Deployment Guide | Section 12 |
| Test Cases | Section 13 |
| Future Work | Section 14 |

---

## Quick Reference: Database Tables

| Table | Rows Est. | Purpose |
|---|---|---|
| Student | ~100s | Registered student accounts |
| Organisation | ~50s | Registered organisations |
| Admin | ~3 | Platform administrators |
| Opportunities | ~200s | Posted opportunities |
| Applications | ~500s | Student applications |
| Feedback | ~100s | Opportunity ratings (star rating per opportunity) |
| StudentInterests | 1 per student | RIASEC quiz results |
| SavedCareerDocs | ~3 per student | AI career documents |
| SavedOpportunities | ~5 per student | Bookmarked opportunities |
| SupportTickets | ~variable | Bug reports & issues from students and orgs |

---

## Quick Reference: Key Tech

| Tech | Version | Role |
|---|---|---|
| Node.js | v18+ | Runtime |
| Express | v5.2.1 | HTTP framework |
| MS SQL Server | Express 2017+ | Database |
| mssql + msnodesqlv8 | v12.2.1 | DB driver |
| bcrypt | v6.0.0 | Password hashing |
| jsonwebtoken | v9.0.3 | JWT auth |
| groq-sdk | v1.1.2 | AI career chatbot |
| nodemailer | v8.0.7 | Email (OTP, reset) |
| dotenv | v17.4.0 | Environment variables |
| axios | v1.15.0 | HTTP requests (external APIs) |
| cookie-parser | v1.4.7 | HTTP-only cookie parsing |
| nodemon | v3.1.14 | Dev auto-restart |
