# Master AI Prompt for Full SMILE Project Documentation

Copy and paste the entire block below into Gemini (or another LLM) to generate your comprehensive, professional 30+ page System Specification and SDLC Document.

***

```markdown
You are a Senior Software Architect and Principal Technical Writer. Your task is to generate an exhaustive, professional, 30+ page **System Architecture and Software Engineering Documentation** for the **SMILE** web platform. 

SMILE is a modern opportunity portal designed specifically for South African youth to discover free jobs, learnerships, educational workshops, and volunteer programs, while allowing registered NGOs and Corporate Organisations to publish opportunities and manage applicants.

Use the comprehensive project context, structural boundaries, API routes, database schemas, and actual production code snippets provided below to write a highly detailed, professional, academic-grade system specification. 

---

# SECTION 1: MASTER DOCUMENT OUTLINE & STRUCTURE

Generate the document matching this exact structural blueprint. Expand each section deeply, avoiding placeholders or generic descriptions. For each diagram slot (demarcated as `[INSERT DIAGRAM]`), write a professional description of what the diagram represents and how it maps to the physical system.

1. **Title Page & Metadata** (SMILE System Specification V2)
2. **Executive Summary & Project Overview** (Background, South African Youth Context, Scope)
3. **Software Development Life Cycle (SDLC) Blueprint**
   - Detailed breakdown of all 7 phases of SDLC tailored to the SMILE project
4. **Database Life Cycle (DBLC) Blueprint**
   - Detailed breakdown of all 8 stages of DBLC tailored to the SMILE database
5. **System Architecture & Tier Topology**
   - Explanation of the 3-Tier Architecture (Client-Side, Server-Side, Database Engine)
   - `[INSERT SYSTEM ARCHITECTURE UML DIAGRAM HERE]`
6. **Detailed Database Architecture (ERD & Schema)**
   - Database engine specifics (MS SQL Server) and connection pooling configuration
   - Complete Schema definition for all 10 relational tables (Data types, constraints, FK relations)
   - `[INSERT ENTITY RELATIONSHIP DIAGRAM (ERD) HERE]`
7. **Use Case Modeling & Responsibility Matrix**
   - System Boundary and Actor Definitions (Student, Organisation, Admin)
   - `[INSERT USE CASE DIAGRAM HERE]`
   - `[INSERT ACTOR ROLE HIERARCHY DIAGRAM HERE]`
   - Comprehensive Use Case Narrative Descriptions (6 core use cases detailed)
8. **API Reference & Endpoint Architecture**
   - Full RESTful API documentation with HTTP methods, route paths, parameters, payloads, and responses
9. **Authentication, State Management, and Security Systems**
   - JWT Auth flow, HTTP-Only Cookie configurations, password hashing (bcrypt), and cross-site protections
10. **Core CRUD Functionality Implementation**
    - Technical deep-dive showing actual Javascript code implementations for:
      - Creating, Reading, Updating, and Deleting (CRUD) **Opportunities**
      - Creating, Reading, Updating, and Deleting (CRUD) **Applications**
      - Creating, Reading, and Resolving **Support Tickets**
11. **Verification, Deployment, & Future Platform Extensions**

---

# SECTION 2: RICH SYSTEM CONTEXT & DOCUMENTATION MATERIAL

## 1. Project Background & Introduction (SMILE Portal)
- **Problem Statement:** High youth unemployment in South Africa, lack of consolidated discoverability of free learnerships, internships, volunteer opportunities, and educational workshops.
- **The Solution:** The SMILE platform provides a localized, beautiful, high-performance split-panel interface. 
- **User Roles:**
  - **Students (Youth):** Can register, take a RIASEC career interest quiz, search geo-coded opportunities near them, save opportunities, apply with an inline bio/motivation, submit support tickets, and chat with an AI career guidance assistant.
  - **Organisations (NGOs/Corporates):** Can register (with live email-deliverability checks & OTP verification), post opportunities (Draft vs. Active), view applicants in a custom management grid, view analytics metrics (funnels, province-wide charts), and approve/shortlist/reject applicants.
  - **Platform Administrators:** Monitor the platform, manage support tickets, moderate users, and oversee opportunity listings.

## 2. Software Development Life Cycle (SDLC) for SMILE
Translate these 7 phases into rich paragraphs describing how SMILE was built:
1. **Planning & Feasibility Study:** Assessing the South African youth unemployment landscape, outlining data requirements, scope definition.
2. **Requirements Analysis:** Defining functional specifications (registration, maps, dashboard, application funnel) and non-functional requirements (JWT security, low-bandwidth CSS optimization).
3. **System Design:** Defining the 3-tier architecture, designing the SQL Server relational model (10 tables), UX/UI styling architecture (CSS variables, vanilla responsive layout).
4. **Implementation & Coding:** Developing server-side controllers in Node.js/Express and front-end scripting with Vanilla JS and CSS.
5. **Testing & Integration:** API manual testing via Postman, client-side validation logic testing (e.g. blocking numbers in names, matching passwords).
6. **Deployment & Installation:** Setting up on local/cloud IIS or Azure/Heroku hosts, importing SQL schemas.
7. **Maintenance & Support:** Implementing support ticket routing, fixing UI display errors, and database connection pooling recovery.

## 3. Database Life Cycle (DBLC) for SMILE
Translate these 8 stages into rich paragraphs describing how the SMILE database was engineered:
1. **Database Initial Study:** Auditing system boundaries (Students, Organisations, Admins, Listings).
2. **Database Design:** Normalizing tables to 3NF, defining core constraints (PK, FK, CHECK).
3. **Implementation & Loading:** Executing SQL DDL scripts to set up schemas, injecting initial mock records.
4. **Testing & Fine-Tuning:** Testing referential integrity cascades (deleting an opportunity cascades to delete corresponding applications).
5. **Deployment:** Configuring physical connection pools inside the Node.js database driver (`mssql` + `msnodesqlv8` for Windows NT Authentication).
6. **Operation:** Running live transactions (Students submitting applications, Organisers updating statuses).
7. **Security & Governance:** Securing credentials using `.env` variables and applying schema access constraints.
8. **Backup & Recovery:** Defining backup strategies for transactional stability.

## 4. 3-Tier System Architecture Model
- **Presentation Layer (Front-End UI):** HTML5 documents, Vanilla CSS (modular stylesheets like `auth-redesign.css`, `orgdashboard.css`), and lightweight front-end Vanilla JS engines (`auth.js`, `orgdashboard.js`).
- **Application Layer (Back-End REST API):** Node.js runtime environment running an Express server. Modular MVC architecture with dedicated routes (`userRoutes.js`, `adminRoute.js`) and controllers (`opportunitiesControllers.js`, `passwordController.js`, `ticketController.js`).
- **Data Layer (Database Engine):** Relational MS SQL Server database. Communicated via `mssql` npm client driver utilizing secure connection pooling.

---

# SECTION 3: TECHNICAL SCHEMAS & ACTUAL CODE RUNTIME

Use the physical DDL schemas and controller code snippets below to write precise technical documentation of the system's inner workings.

### A. Core Relational Database Schema (DDL)
Here is the official structural DDL schema of the database tables, including the new Support Tickets addition:

```sql
-- 1. Student Table
CREATE TABLE [dbo].[Student] (
    [StuID]               INT            IDENTITY(1,1) NOT NULL,
    [StuName]             VARCHAR(50)    NOT NULL,
    [StuLastName]         VARCHAR(50)    NOT NULL,
    [StuEmail]            VARCHAR(100)   NOT NULL UNIQUE,
    [StuProvince]         VARCHAR(50)    NOT NULL,
    [StuEducationLevel]   VARCHAR(50)    NOT NULL,
    [StuPassword]         VARCHAR(255)   NOT NULL,
    [StuPhone]            VARCHAR(20)    NULL,
    [StuBio]              VARCHAR(MAX)   NULL,
    [ProfilePicUrl]       VARCHAR(255)   NULL,
    [ResetToken]          VARCHAR(255)   NULL,
    [ResetTokenExpiry]    DATETIME       NULL,
    [DateCreated]         DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Student] PRIMARY KEY CLUSTERED ([StuID] ASC)
);

-- 2. Organisation Table
CREATE TABLE [dbo].[Organisation] (
    [OrgId]               INT            IDENTITY(1,1) NOT NULL,
    [OrgName]             VARCHAR(100)   NOT NULL,
    [OrgEmail]            VARCHAR(100)   NOT NULL UNIQUE,
    [OrgType]             VARCHAR(50)    NOT NULL,
    [OrgProvince]         VARCHAR(50)    NOT NULL,
    [Password]            VARCHAR(255)   NOT NULL,
    [Status]              VARCHAR(20)    NOT NULL DEFAULT 'Pending', -- 'Pending' | 'Active' | 'Rejected'
    [ResetToken]          VARCHAR(255)   NULL,
    [ResetTokenExpiry]    DATETIME       NULL,
    [DateCreated]         DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Organisation] PRIMARY KEY CLUSTERED ([OrgId] ASC),
    CONSTRAINT [CHK_OrgStatus] CHECK ([Status] IN ('Pending', 'Active', 'Rejected'))
);

-- 3. Admin Table
CREATE TABLE [dbo].[Admin] (
    [AdminID]             INT            IDENTITY(1,1) NOT NULL,
    [AdminName]           VARCHAR(100)   NOT NULL,
    [AdminEmail]          VARCHAR(255)   NOT NULL UNIQUE,
    [AdminPassword]       VARCHAR(255)   NOT NULL,
    [CreatedAt]           DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Admin] PRIMARY KEY CLUSTERED ([AdminID] ASC)
);

-- 4. Opportunities Table
CREATE TABLE [dbo].[Opportunities] (
    [OppID]               INT            IDENTITY(1,1) NOT NULL,
    [OrgId]               INT            NOT NULL,
    [Title]               VARCHAR(120)   NOT NULL,
    [OppType]             VARCHAR(50)    NOT NULL, -- 'Learnership' | 'Internship' | 'Workshop' | 'Volunteer'
    [Province]            VARCHAR(50)    NOT NULL,
    [Address]             VARCHAR(255)   NULL,
    [Description]         VARCHAR(MAX)   NOT NULL,
    [Requirements]        VARCHAR(MAX)   NULL,
    [ApplicationDeadline] DATE           NOT NULL,
    [StartDate]           DATE           NULL,
    [ApplicationLink]     VARCHAR(255)   NULL,
    [MaxApplicants]       INT            NULL,
    [Status]              VARCHAR(20)    NOT NULL DEFAULT 'Active', -- 'Active' | 'Closed'
    [DateCreated]         DATETIME       NOT NULL DEFAULT GETDATE(),
    [Lat]                 DECIMAL(9,6)   NULL,
    [Lng]                 DECIMAL(9,6)   NULL,
    CONSTRAINT [PK_Opportunities] PRIMARY KEY CLUSTERED ([OppID] ASC),
    CONSTRAINT [FK_Opportunities_Organisation] FOREIGN KEY ([OrgId]) REFERENCES [dbo].[Organisation] ([OrgId]) ON DELETE CASCADE
);

-- 5. Applications Table (Student applying to Opportunities)
CREATE TABLE [dbo].[Applications] (
    [AppID]               INT            IDENTITY(1,1) NOT NULL,
    [StuID]               INT            NOT NULL,
    [OppID]               INT            NOT NULL,
    [Status]              VARCHAR(20)    NOT NULL DEFAULT 'Pending', -- 'Pending' | 'Reviewed' | 'Shortlisted' | 'Rejected'
    [DateApplied]         DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Applications] PRIMARY KEY CLUSTERED ([AppID] ASC),
    CONSTRAINT [FK_Applications_Student] FOREIGN KEY ([StuID]) REFERENCES [dbo].[Student] ([StuID]),
    CONSTRAINT [FK_Applications_Opportunities] FOREIGN KEY ([OppID]) REFERENCES [dbo].[Opportunities] ([OppID]) ON DELETE CASCADE,
    CONSTRAINT [UQ_Student_Opp] UNIQUE ([StuID], [OppID])
);

-- 6. Feedback Table (Opportunity rating & comments)
CREATE TABLE [dbo].[Feedback] (
    [FeedbackID]          INT            IDENTITY(1,1) NOT NULL,
    [OppID]               INT            NOT NULL,
    [StuID]               INT            NOT NULL,
    [Rating]              INT            NOT NULL,
    [Comment]             VARCHAR(MAX)   NULL,
    [DateSubmitted]       DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Feedback] PRIMARY KEY CLUSTERED ([FeedbackID] ASC),
    CONSTRAINT [FK_Feedback_Opportunities] FOREIGN KEY ([OppID]) REFERENCES [dbo].[Opportunities] ([OppID]) ON DELETE CASCADE,
    CONSTRAINT [FK_Feedback_Student] FOREIGN KEY ([StuID]) REFERENCES [dbo].[Student] ([StuID]) ON DELETE CASCADE,
    CONSTRAINT [CHK_Rating] CHECK ([Rating] >= 1 AND [Rating] <= 5)
);

-- 7. StudentInterests Table (RIASEC Quiz results)
CREATE TABLE [dbo].[StudentInterests] (
    [InterestID]          INT            IDENTITY(1,1) NOT NULL,
    [StuID]               INT            NOT NULL UNIQUE,
    [Realistic]           INT            NOT NULL DEFAULT 0,
    [Investigative]       INT            NOT NULL DEFAULT 0,
    [Artistic]            INT            NOT NULL DEFAULT 0,
    [Social]              INT            NOT NULL DEFAULT 0,
    [Enterprising]        INT            NOT NULL DEFAULT 0,
    [Conventional]        INT            NOT NULL DEFAULT 0,
    [TopInterest]         VARCHAR(50)    NULL,
    [DateTaken]           DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_StudentInterests] PRIMARY KEY CLUSTERED ([InterestID] ASC),
    CONSTRAINT [FK_StudentInterests_Student] FOREIGN KEY ([StuID]) REFERENCES [dbo].[Student] ([StuID]) ON DELETE CASCADE
);

-- 8. SavedCareerDocs Table (AI-generated Documents)
CREATE TABLE [dbo].[SavedCareerDocs] (
    [DocID]               INT            IDENTITY(1,1) NOT NULL,
    [StuID]               INT            NOT NULL,
    [CareerTitle]         VARCHAR(100)   NOT NULL,
    [DocContent]          NVARCHAR(MAX)  NOT NULL,
    [DateSaved]           DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_SavedCareerDocs] PRIMARY KEY CLUSTERED ([DocID] ASC),
    CONSTRAINT [FK_SavedCareerDocs_Student] FOREIGN KEY ([StuID]) REFERENCES [dbo].[Student] ([StuID]) ON DELETE CASCADE
);

-- 9. SavedOpportunities Table (Bookmarked opportunities)
CREATE TABLE [dbo].[SavedOpportunities] (
    [SaveID]              INT            IDENTITY(1,1) NOT NULL,
    [StuID]               INT            NOT NULL,
    [OppID]               INT            NOT NULL,
    [DateSaved]           DATETIME       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_SavedOpportunities] PRIMARY KEY CLUSTERED ([SaveID] ASC),
    CONSTRAINT [FK_SavedOpportunities_Student] FOREIGN KEY ([StuID]) REFERENCES [dbo].[Student] ([StuID]) ON DELETE CASCADE,
    CONSTRAINT [FK_SavedOpportunities_Opportunities] FOREIGN KEY ([OppID]) REFERENCES [dbo].[Opportunities] ([OppID]) ON DELETE CASCADE,
    CONSTRAINT [UQ_Saved_Student_Opp] UNIQUE ([StuID], [OppID])
);

-- 10. Support Tickets Table (Student/Organisation Bug reporting & Report flow)
CREATE TABLE [dbo].[SupportTickets] (
    [TicketID]            INT            IDENTITY(1,1) NOT NULL,
    [SubmitterID]         INT            NOT NULL,            -- StuID or OrgId
    [SubmitterType]       VARCHAR(10)    NOT NULL,            -- 'student' or 'org'
    [TicketType]          VARCHAR(30)    NOT NULL,            -- 'Bug / Issue' or 'Report'
    [Subject]             VARCHAR(255)   NOT NULL,
    [Description]         NVARCHAR(MAX)  NOT NULL,
    [Status]              VARCHAR(20)    NOT NULL DEFAULT 'Open', -- 'Open' | 'Resolved'
    [AdminFeedback]       NVARCHAR(MAX)  NULL,
    [DateCreated]         DATETIME       NOT NULL DEFAULT GETDATE(),
    [DateResolved]        DATETIME       NULL,
    CONSTRAINT [PK_SupportTickets] PRIMARY KEY CLUSTERED ([TicketID] ASC),
    CONSTRAINT [CHK_TicketStatus] CHECK ([Status] IN ('Open', 'Resolved')),
    CONSTRAINT [CHK_SubmitterType] CHECK ([SubmitterType] IN ('student', 'org'))
);
```

### B. RESTful API Routes Reference
Document these routes inside the *API Reference* section:

| Route Path | Method | Auth | Description |
|---|---|---|---|
| `/api/opportunities` | `POST` | Org JWT | Create a new opportunity (Accepts title, type, desc, deadline etc.) |
| `/api/opportunities` | `GET` | Public | Retrieve all active opportunities (Supports filters: type, province, search, sort) |
| `/api/opportunities/:oppId` | `PUT` | Org JWT | Edit and update opportunity |
| `/api/opportunities/:oppId` | `DELETE` | Org JWT | Delete an opportunity (Cascades applications) |
| `/api/org/applicants` | `GET` | Org JWT | Fetch all student applicants for the logged-in Organisation |
| `/api/org/applicants/:appId/status` | `PATCH` | Org JWT | Update applicant status (Shortlist, Reject, Review) |
| `/api/org/dashboard-stats` | `GET` | Org JWT | Retrieve stats metrics (funnels, recent feeds, timeline chart) |
| `/api/student/saved-opportunities` | `GET` | Stud JWT | Retrieve student's saved bookmarks |
| `/api/student/saved-opportunities` | `POST` | Stud JWT | Save a new opportunity bookmark |
| `/api/student/saved-opportunities/:oppId` | `DELETE` | Stud JWT | Remove a saved opportunity bookmark |
| `/api/tickets` | `POST` | Any JWT | Submit a new support bug / report ticket |
| `/api/tickets/my` | `GET` | Any JWT | Retrieve authenticated user's submitted support tickets |
| `/admin/api/tickets` | `GET` | Admin JWT | Retrieve all support tickets (Admin dashboard) |
| `/admin/api/tickets/:id` | `PATCH` | Admin JWT | Resolve support ticket + add feedback (Admin dashboard) |

---

### C. Core Backend CRUD Implementations (Express Controllers)

#### 1. Opportunity CRUD Operations
Show how Organisations create, update, and delete opportunity listings:

```javascript
// [CREATE] controllers/opportunitiesControllers.js
export const createNewOpportunity = async (req, res) => {
    try {
        const { title, type, address, province, maxApplicants, description, requirements, deadline, startDate, applicationLink } = req.body;
        const orgId = req.user?.id;
        if (!orgId || req.user?.accountType !== "organization") {
            return res.status(401).json({ success: false, message: "Unauthorised." });
        }

        const coords = await getCoordinates(address, province); // Geo API Integration
        const pool = await connectToDB();

        await pool.request()
            .input("OrgId",               sql.Int,           orgId)
            .input("Title",               sql.VarChar(120),  title)
            .input("OppType",             sql.VarChar(50),   type)
            .input("Province",            sql.VarChar(50),   province)
            .input("Description",         sql.VarChar,       description)
            .input("Requirements",        sql.VarChar,       requirements   || null)
            .input("ApplicationLink",     sql.VarChar(255),  applicationLink || null)
            .input("MaxApplicants",       sql.Int,           maxApplicants  || null)
            .input("ApplicationDeadline", sql.Date,          deadline)
            .input("StartDate",           sql.Date,          startDate      || null)
            .input("Lat",                 sql.Decimal(9,6),  coords.lat)
            .input("Lng",                 sql.Decimal(9,6),  coords.lng)
            .query(`
                INSERT INTO [dbo].[Opportunities]
                    (OrgId, Title, OppType, Province, Description, Requirements,
                     ApplicationLink, MaxApplicants, ApplicationDeadline, StartDate, Lat, Lng)
                VALUES
                    (@OrgId, @Title, @OppType, @Province, @Description, @Requirements,
                     @ApplicationLink, @MaxApplicants, @ApplicationDeadline, @StartDate, @Lat, @Lng)
            `);

        return res.status(201).json({ success: true, message: "Opportunity published successfully!" });
    } catch (err) {
        return res.status(500).json({ success: false, message: "Something went wrong." });
    }
};

// [UPDATE] controllers/opportunitiesControllers.js
export const updateOpportunity = async (req, res) => {
    try {
        const orgId = req.user?.id;
        const { oppId } = req.params;
        const { title, type, address, province, maxApplicants, description, requirements, deadline, startDate, applicationLink, status } = req.body;

        const coords = await getCoordinates(address, province);
        const pool = await connectToDB();

        await pool.request()
            .input("OppID",               sql.Int,           oppId)
            .input("Title",               sql.VarChar(120),  title)
            .input("OppType",             sql.VarChar(50),   type)
            .input("Province",            sql.VarChar(50),   province)
            .input("Description",         sql.VarChar,       description)
            .input("Requirements",        sql.VarChar,       requirements   || null)
            .input("ApplicationLink",     sql.VarChar(255),  applicationLink || null)
            .input("MaxApplicants",       sql.Int,           maxApplicants  || null)
            .input("ApplicationDeadline", sql.Date,          deadline)
            .input("StartDate",           sql.Date,          startDate      || null)
            .input("Status",              sql.VarChar(20),   status         || "Active")
            .input("Lat",                 sql.Decimal(9,6),  coords.lat)
            .input("Lng",                 sql.Decimal(9,6),  coords.lng)
            .query(`
                UPDATE Opportunities
                SET Title = @Title, OppType = @OppType, Province = @Province, Description = @Description,
                    Requirements = @Requirements, ApplicationLink = @ApplicationLink, MaxApplicants = @MaxApplicants,
                    ApplicationDeadline = @ApplicationDeadline, StartDate = @StartDate, Status = @Status, Lat = @Lat, Lng = @Lng
                WHERE OppID = @OppID
            `);

        return res.status(200).json({ success: true, message: "Opportunity updated successfully!" });
    } catch (err) {
        return res.status(500).json({ success: false, message: "Failed to update." });
    }
};
```

#### 2. Applicant Status Operations
Show how application processing works, including instant status updating:

```javascript
// [UPDATE STATUS] controllers/opportunitiesControllers.js
export const updateApplicationStatus = async (req, res) => {
    try {
        const orgId = req.user?.id;
        const { appId } = req.params;
        const { status } = req.body;

        const allowed = ['Pending', 'Reviewed', 'Shortlisted', 'Rejected'];
        if (!allowed.includes(status)) {
            return res.status(400).json({ success: false, message: "Invalid status value." });
        }

        const pool = await connectToDB();

        // 1. Verify ownership
        const check = await pool.request()
            .input("AppId", sql.Int, appId)
            .input("OrgId", sql.Int, orgId)
            .query(`
                SELECT a.AppID FROM Applications a
                JOIN Opportunities o ON a.OppID = o.OppID
                WHERE a.AppID = @AppId AND o.OrgId = @OrgId
            `);

        if (check.recordset.length === 0) {
            return res.status(404).json({ success: false, message: "Application not found." });
        }

        // 2. Perform Transactional update
        await pool.request()
            .input("AppId", sql.Int, appId)
            .input("Status", sql.VarChar(20), status)
            .query(`UPDATE Applications SET Status = @Status WHERE AppID = @AppId`);

        return res.status(200).json({ success: true, message: `Status updated to ${status}` });
    } catch (err) {
        return res.status(500).json({ success: false, message: "Failed to update status." });
    }
};
```

#### 3. Support Tickets CRUD Operations
Show how users submit platform bug feedback and reports:

```javascript
// [CREATE TICKET] controllers/ticketController.js
export const createTicket = async (req, res) => {
    try {
        const { ticketType, subject, description } = req.body;
        const submitterId = req.user?.id;
        const submitterType = req.user?.accountType === "organization" ? "org" : "student";

        if (!ticketType || !subject || !description) {
            return res.status(400).json({ success: false, message: "Please fill in all fields." });
        }

        const pool = await connectToDB();
        await pool.request()
            .input("SubID", sql.Int, submitterId)
            .input("SubType", sql.VarChar(10), submitterType)
            .input("TktType", sql.VarChar(30), ticketType)
            .input("Subj", sql.VarChar(255), subject)
            .input("Desc", sql.NVarChar, description)
            .query(`
                INSERT INTO [dbo].[SupportTickets] (SubmitterID, SubmitterType, TicketType, Subject, Description)
                VALUES (@SubID, @SubType, @TktType, @Subj, @Desc)
            `);

        return res.status(201).json({ success: true, message: "Ticket submitted successfully!" });
    } catch (err) {
        return res.status(500).json({ success: false, message: "Failed to submit ticket." });
    }
};
```

---

# SECTION 4: INSTRUCTIONS FOR EXPANSION & WRITING STYLE

When writing the output, adopt the perspective of a meticulous software engineer writing a formal corporate technical report.
- **Tone:** Academic, highly descriptive, technical, and complete. Do not abbreviate or summarize lists.
- **Deep Explanations:** For example, when describing the DBLC, do not just list the 8 stages. Dedicate 2-3 detailed paragraphs to *each* stage, explaining how mssql drivers work, how connection pools recover under crash load, and how constraints maintain integrity inside the relational schema.
- **Diagram Descriptions:** Wherever the structure has a `[INSERT DIAGRAM]` slot, generate a detailed paragraph describing exactly what the diagram will display physically (e.g. describing the Use Case associations, ERD entities, PK/FK links, and role hierarchies) so the user can easily match their draw.io export images to your sections.
- **Code Breakdown:** Analyze each code snippet inside the document, explaining key parameters (like connection pools, JWT signatures, payload sanitizations, and SQL parameters to block SQL injections).

Now, generate the complete, extensive 30+ page documentation based on this structural outline and rich technical context.
```
