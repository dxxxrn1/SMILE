# SMILE – Full Project Documentation

**Project Name:** SMILE — Student Mentorship, Internship, Learnerships & Employment Platform  
**Version:** 1.0  
**Authors:** Lucas Bohani Maluleke & Darren Foster  
**Date:** May 2026  
**Technology Stack:** Node.js / Express / MS SQL Server / HTML / CSS / JavaScript  

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [System Requirements](#2-system-requirements)
3. [System Architecture](#3-system-architecture)
4. [Database Design](#4-database-design)
5. [Frontend Design & Pages](#5-frontend-design--pages)
6. [Backend API Reference](#6-backend-api-reference)
7. [Authentication & Security](#7-authentication--security)
8. [External Integrations](#8-external-integrations)
9. [Feature Modules](#9-feature-modules)
10. [SDLC Documentation](#10-sdlc-documentation)
11. [Database Life Cycle (DBLC)](#11-database-life-cycle-dblc)
12. [Deployment Guide](#12-deployment-guide)
13. [Testing](#13-testing)
14. [Known Issues & Future Work](#14-known-issues--future-work)

---

## 1. Project Overview

### 1.1 Background

SMILE is a web-based platform designed to connect **South African students** with **internship, learnership, volunteer, and employment opportunities** posted by registered organisations. The platform also provides AI-powered career guidance to help students identify their strengths and plan their professional futures.

### 1.2 Problem Statement

Many South African students struggle to find legitimate internship and learnership opportunities, and lack structured guidance on career paths suited to their interests and education level. Organisations also lack a centralised platform to reach and screen student applicants efficiently.

### 1.3 Solution

SMILE provides a tri-portal system:
- **Student Portal** — discover, apply, and plan careers
- **Organisation Portal** — post and manage opportunities, track applicants
- **Admin Portal** — moderate organisations and maintain platform integrity

### 1.4 Key Features

| Feature | Description |
|---|---|
| Multi-role registration & login | Student, Organisation, Admin with JWT auth |
| OTP email verification | Email confirmed via OTP before registration completes |
| Opportunity marketplace | Browse, filter, search, and apply for opportunities |
| Geo-location mapping | "Near Me" map showing opportunities plotted on coordinates |
| AI Career Chatbot | Powered by Groq (LLaMA 3.3 70B) for personalised career advice |
| RIASEC Interest Quiz | Holland's occupational model personality assessment |
| Career document generation | AI-generated structured career path PDF-ready document |
| News feed | Daily South African news via external News API |
| Career listings | Live job listings via external Jobs API |
| Organisation management | Full CRUD for opportunities, applicant status workflow |
| Admin moderation | Approve/reject/delete organisations and students |

---

## 2. System Requirements

### 2.1 Functional Requirements

| ID | Requirement |
|---|---|
| FR-01 | The system shall allow students to register with email, name, province, education level, and password |
| FR-02 | The system shall allow organisations to register with name, email, type, province, and password |
| FR-03 | The system shall send an OTP verification email during registration |
| FR-04 | The system shall authenticate users with JWT stored in HTTP-only cookies |
| FR-05 | The system shall allow students to browse opportunities with filtering by type and province |
| FR-06 | The system shall allow students to apply for opportunities (one application per student per opportunity) |
| FR-07 | The system shall display opportunities on a map using geo-coordinates |
| FR-08 | The system shall provide an AI career chatbot based on student interest profile |
| FR-09 | The system shall allow students to take a RIASEC personality quiz and save results |
| FR-10 | The system shall allow organisations to post, edit, and delete opportunities |
| FR-11 | The system shall allow organisations to view and update applicant statuses |
| FR-12 | The system shall allow administrators to approve or reject organisations |
| FR-13 | The system shall support forgot/reset password via email link |
| FR-14 | The system shall generate AI career path documents and save them to the database |

### 2.2 Non-Functional Requirements

| ID | Requirement | Target |
|---|---|---|
| NFR-01 | Performance | Page load < 3 seconds on standard connection |
| NFR-02 | Security | All passwords bcrypt-hashed (rounds ≥ 10); JWT secret via env var |
| NFR-03 | Availability | Server runs 24/7 on Node.js with nodemon dev restarts |
| NFR-04 | Usability | Responsive design; works on desktop and tablet |
| NFR-05 | Maintainability | MVC pattern; controllers separated from routes |
| NFR-06 | Scalability | Connection-pooled MSSQL; stateless JWT auth |

### 2.3 Technical Requirements

| Component | Requirement |
|---|---|
| Runtime | Node.js v18+ |
| Framework | Express v5 |
| Database | MS SQL Server Express 2017+ |
| ODBC Driver | ODBC Driver 18 for SQL Server |
| OS | Windows (Trusted_Connection Windows Auth) |
| Browser | Chrome, Firefox, Edge (modern versions) |

---

## 3. System Architecture

### 3.1 Architecture Pattern

SMILE uses the **3-Tier MVC (Model-View-Controller)** architecture:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PRESENTATION TIER                                  │
│          HTML5 Pages  |  Vanilla CSS  |  Frontend JavaScript         │
│          (17 HTML pages, jsFrontEnd/ directory)                       │
└───────────────────────────┬─────────────────────────────────────────┘
                            │  HTTP/HTTPS REST API
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    APPLICATION TIER                                   │
│               Node.js + Express v5 (main.js)                         │
│  ┌──────────────┐  ┌──────────────────────────────────────────────┐ │
│  │   ROUTES     │  │              CONTROLLERS                     │ │
│  │ userRoutes   │  │ userControllers   │ studentController        │ │
│  │ adminRoute   │  │ opportunitiesCtrl │ chatbotController        │ │
│  └──────────────┘  │ adminController  │ sessionControllers       │ │
│                    │ passwordController│ otpController           │ │
│  ┌──────────────┐  │ pageControllers  │                          │ │
│  │  EXTERNAL    │  └──────────────────────────────────────────────┘ │
│  │    APIS      │                                                     │
│  │ newsAPI      │  ┌──────────────────────────────────────────────┐ │
│  │ careers      │  │           MIDDLEWARE                         │ │
│  │ booksAPI     │  │  express.json | cookieParser | static files  │ │
│  │ geoHelper    │  │  verifyToken  | requireAdmin                 │ │
│  └──────────────┘  └──────────────────────────────────────────────┘ │
└───────────────────────────┬─────────────────────────────────────────┘
                            │  MSSQL / ODBC Driver 18 / Windows Auth
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│                       DATA TIER                                       │
│              MS SQL Server Express — Database: SMILE                 │
│  Admin | Student | Organisation | Opportunities | Applications       │
│  Feedback | StudentInterests | SavedCareerDocs | SavedOpportunities  │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 Request-Response Flow

```
Browser → Fetch API → Express Router → Middleware (verifyToken) 
       → Controller → DB Query (mssql pool) → Response JSON
       → Browser updates DOM
```

### 3.3 Project File Structure

```
SMILE-1/
├── package.json                    # Project metadata & dependencies
├── .env                            # Environment variables (not committed)
├── src/
│   ├── frontEnd/
│   │   ├── htmlPages/              # 17 HTML page files
│   │   │   ├── home.html           # Landing page
│   │   │   ├── login.html          # Login/Register page
│   │   │   ├── register.html       # Registration page
│   │   │   ├── studentdashboard.html
│   │   │   ├── orgdashboard.html
│   │   │   ├── admin.html
│   │   │   ├── createOpportunity.html
│   │   │   ├── applicants.html
│   │   │   ├── analytics.html
│   │   │   ├── nearme.html
│   │   │   ├── news.html
│   │   │   ├── careers.html
│   │   │   ├── studentProfile.html
│   │   │   ├── forget-password.html
│   │   │   ├── reset-password.html
│   │   │   ├── userModeration.html
│   │   │   └── userTicket.html
│   │   ├── jsFrontEnd/             # Frontend JavaScript files
│   │   ├── css/                    # Stylesheets
│   │   └── Assets/                 # Images and static assets
│   └── server/
│       ├── main.js                 # Express app entry point (port 3000)
│       ├── routes/
│       │   ├── userRoutes.js       # All student/org/public routes
│       │   └── adminRoute.js       # Admin-only routes
│       ├── controllers/
│       │   ├── userControllers.js  # Register & Login logic
│       │   ├── studentController.js
│       │   ├── opportunitiesControllers.js
│       │   ├── chatbotController.js
│       │   ├── adminController.js
│       │   ├── sessionControllers.js
│       │   ├── passwordController.js
│       │   ├── otpController.js
│       │   └── pageControllers.js
│       ├── apis/
│       │   ├── newsAPI.js
│       │   ├── careers.js
│       │   ├── booksAPI.js
│       │   └── geoHelper.js
│       ├── dbConnection/
│       │   └── dbconnection.js     # MSSQL connection pool
│       └── sql/
│           ├── smileScript.sql     # Full DB creation script
│           ├── schema.sql          # Basic schema
│           ├── createOppertunity.sql
│           ├── createSavedOpportunities.sql
│           └── ...
└── docx/                           # Project documentation
```

---

## 4. Database Design

### 4.1 Database Summary

| Property | Value |
|---|---|
| DBMS | Microsoft SQL Server Express |
| Database Name | SMILE |
| Collation | DATABASE_DEFAULT |
| Auth | Windows Trusted_Connection |
| Tables | 10 |
| Total Relationships | 12 foreign key constraints |

### 4.2 Tables

#### 4.2.1 Student
Stores all registered student user accounts.

| Column | Type | Constraints | Description |
|---|---|---|---|
| StuID | INT IDENTITY | PK | Auto-increment primary key |
| StuName | VARCHAR(255) | NOT NULL | First name |
| StuLastName | VARCHAR(255) | NOT NULL | Last name |
| StuEmail | VARCHAR(255) | NOT NULL | Login email |
| StuProvince | VARCHAR(255) | NOT NULL | Province |
| StuEducationLevel | VARCHAR(255) | NOT NULL | Education level |
| StuPassword | VARCHAR(255) | NOT NULL | bcrypt-hashed password |
| StuBio | NVARCHAR(MAX) | NULL | Optional bio |
| ProfilePicUrl | NVARCHAR(255) | NULL | Profile picture URL |
| DateCreated | DATETIME | DEFAULT GETDATE() | Account creation date |

#### 4.2.2 Organisation
Stores registered organisations. Must be approved by Admin before full access.

| Column | Type | Constraints | Description |
|---|---|---|---|
| OrgId | INT IDENTITY | PK | Auto-increment primary key |
| OrgName | VARCHAR(255) | NOT NULL | Organisation name |
| OrgEmail | VARCHAR(255) | NOT NULL | Login email |
| Type | VARCHAR(255) | NOT NULL | Organisation type (NGO, Company, etc.) |
| Province | VARCHAR(255) | NOT NULL | Province |
| Password | VARCHAR(255) | NOT NULL | bcrypt-hashed password |
| Status | VARCHAR(20) | CHECK, DEFAULT 'Pending' | Pending / Active / Rejected |
| DateCreated | DATETIME | DEFAULT GETDATE() | Registration date |

#### 4.2.3 Admin
Stores system administrator accounts. Admins log in using the Organisation login card.

| Column | Type | Constraints | Description |
|---|---|---|---|
| AdminID | INT IDENTITY | PK | Primary key |
| AdminName | VARCHAR(100) | NOT NULL | Admin name |
| AdminEmail | VARCHAR(255) | UNIQUE, NOT NULL | Unique login email |
| AdminPassword | VARCHAR(255) | NOT NULL | bcrypt-hashed password |
| CreatedAt | DATETIME | DEFAULT GETDATE() | Account creation date |

#### 4.2.4 Opportunities
Opportunities posted by organisations.

| Column | Type | Constraints | Description |
|---|---|---|---|
| OppID | INT IDENTITY | PK | Primary key |
| OrgId | INT | FK → Organisation, CASCADE | Posting organisation |
| Title | VARCHAR(120) | NOT NULL | Opportunity title |
| OppType | VARCHAR(50) | NOT NULL | Internship / Learnership / Volunteer / Employment |
| Province | VARCHAR(50) | NOT NULL | Location province |
| Description | VARCHAR(MAX) | NOT NULL | Full description |
| Requirements | VARCHAR(MAX) | NULL | Optional requirements |
| ApplicationLink | VARCHAR(255) | NULL | External link (optional) |
| MaxApplicants | INT | NULL | Max allowed applicants |
| ApplicationDeadline | DATE | NOT NULL | Application closing date |
| StartDate | DATE | NULL | Programme start date |
| Status | VARCHAR(20) | DEFAULT 'Active' | Active / Closed |
| Lat | DECIMAL(9,6) | NULL | Geo-latitude |
| Lng | DECIMAL(9,6) | NULL | Geo-longitude |
| DateCreated | DATETIME | DEFAULT GETDATE() | Post creation date |

#### 4.2.5 Applications
Junction table linking students to opportunities they applied for.

| Column | Type | Constraints | Description |
|---|---|---|---|
| AppID | INT IDENTITY | PK | Primary key |
| OppID | INT | FK → Opportunities (CASCADE) | Applied opportunity |
| StuID | INT | FK → Student (CASCADE) | Applicant |
| Status | VARCHAR(20) | DEFAULT 'Pending' | Pending / Reviewed / Shortlisted / Rejected |
| DateApplied | DATETIME | DEFAULT GETDATE() | Application submission date |
| — | — | UNIQUE(OppID, StuID) | One application per student per opportunity |

#### 4.2.6 Feedback
Allows students to rate and comment on opportunities.

| Column | Type | Constraints | Description |
|---|---|---|---|
| FeedbackID | INT IDENTITY | PK | Primary key |
| OppID | INT | FK → Opportunities (CASCADE) | Rated opportunity |
| StuID | INT | FK → Student (CASCADE) | Student who rated |
| Rating | INT | CHECK (1–5) | Star rating 1 to 5 |
| Comment | VARCHAR(MAX) | NULL | Optional text feedback |
| DateSubmitted | DATETIME | DEFAULT GETDATE() | Submission date |

#### 4.2.7 StudentInterests
Stores RIASEC personality quiz results for each student (1:1 with Student).

| Column | Type | Description |
|---|---|---|
| InterestID | INT IDENTITY PK | Primary key |
| StuID | INT FK UNIQUE | Links to Student (one result per student) |
| Realistic | INT (default 0) | RIASEC R score |
| Investigative | INT (default 0) | RIASEC I score |
| Artistic | INT (default 0) | RIASEC A score |
| Social | INT (default 0) | RIASEC S score |
| Enterprising | INT (default 0) | RIASEC E score |
| Conventional | INT (default 0) | RIASEC C score |
| TopInterest | VARCHAR(50) | Highest scoring category |
| DateTaken | DATETIME | Quiz completion date |

#### 4.2.8 SavedCareerDocs
AI-generated career path documents saved per student.

| Column | Type | Description |
|---|---|---|
| DocID | INT IDENTITY PK | Primary key |
| StuID | INT FK | Links to Student |
| CareerTitle | VARCHAR(100) | Document title |
| DocContent | NVARCHAR(MAX) | Full AI-generated markdown content |
| DateSaved | DATETIME | Save date |

#### 4.2.9 SavedOpportunities
Junction table for bookmarked opportunities.

| Column | Type | Description |
|---|---|---|
| SaveID | INT IDENTITY PK | Primary key |
| StuID | INT FK CASCADE | Links to Student |
| OppID | INT FK CASCADE | Links to Opportunities |
| DateSaved | DATETIME | Bookmark date |
| — | UNIQUE(StuID, OppID) | No duplicate bookmarks |

#### 4.2.10 SupportTickets
Stores support tickets, reports, and feedback submitted by students and organisations.

| Column | Type | Constraints | Description |
|---|---|---|---|
| TicketID | INT IDENTITY | PK | Auto-increment primary key |
| SubmitterID | INT | NOT NULL | Submitting Student ID or Organisation ID |
| SubmitterType | VARCHAR(10) | NOT NULL, CHECK | Submitter role ('student' or 'org') |
| TicketType | VARCHAR(30) | NOT NULL | Type of ticket ('Bug / Issue' or 'Report') |
| Subject | VARCHAR(255) | NOT NULL | Ticket subject line |
| Description | NVARCHAR(MAX) | NOT NULL | In-depth issue description |
| Status | VARCHAR(20) | CHECK, DEFAULT 'Open' | Ticket state ('Open' or 'Resolved') |
| AdminFeedback | NVARCHAR(MAX) | NULL | Optional feedback comments from administrator |
| DateCreated | DATETIME | DEFAULT GETDATE() | Ticket submission timestamp |
| DateResolved | DATETIME | NULL | Timestamp when administrator resolved the ticket |

### 4.3 Entity Relationships

```
Organisation ──────< Opportunities >─────< Applications >───── Student
          \                          \                              |
           \                          └──────< Feedback >──────────┘
            \                                                       |
             \───┐                                      StudentInterests (1:1)
                 ├───< SupportTickets >─────────┐       SavedCareerDocs (1:M)
             ┌───┘                              │       SavedOpportunities (M:M)
             Student ───────────────────────────┘
```

---

## 5. Frontend Design & Pages

### 5.1 Page Inventory

| Page | File | Access | Description |
|---|---|---|---|
| Home / Landing | home.html | Public | Platform introduction and CTAs |
| Login | login.html | Public | Login form (Student or Org/Admin) |
| Register | register.html | Public | Tabbed registration for Student or Organisation |
| Forgot Password | forget-password.html | Public | Email entry for reset link |
| Reset Password | reset-password.html | Public | New password entry |
| Student Dashboard | studentdashboard.html | Student | Opportunities, applications, career tools |
| Student Profile | studentProfile.html | Student | View/edit profile, bio, picture |
| Near Me | nearme.html | Student | Interactive map of nearby opportunities |
| News | news.html | Student | Daily South African news feed |
| Careers | careers.html | Student | External job listings browser |
| Org Dashboard | orgdashboard.html | Organisation | Full management portal |
| Create Opportunity | createOpportunity.html | Organisation | Opportunity creation form |
| Applicants | applicants.html | Organisation | Applicant list and status management |
| Analytics | analytics.html | Organisation | Charts and statistics |
| Admin Dashboard | admin.html | Admin | Organisation moderation panel |
| User Moderation | userModeration.html | Admin | Student management |
| User Ticket | userTicket.html | Admin | Support ticket interface |

### 5.2 Navigation Flow

```
Guest
  ↓
Home Page → Login → [Student Dashboard] → Opportunities → Apply
                  → [Org Dashboard] → Create Opportunity
                  → [Admin Dashboard] → Approve Orgs
```

---

## 6. Backend API Reference

### 6.1 Public Routes (No Auth Required)

| Method | Endpoint | Description |
|---|---|---|
| GET | / | Home page |
| GET | /login-page | Login page |
| GET | /register-page | Register page |
| POST | /register/student | Create student account |
| POST | /register/organization | Create organisation account |
| POST | /login | Authenticate user (returns JWT cookie) |
| POST | /api/send-otp | Send OTP verification email |
| POST | /api/verify-otp | Verify OTP code |
| GET | /forgot-password | Forgot password page |
| POST | /forgot-password | Send reset password email |
| POST | /reset-password | Update password with reset token |
| GET | /api/jobs | External job listings (public) |

### 6.2 Student Routes (JWT Required)

| Method | Endpoint | Description |
|---|---|---|
| GET | /student/dashboard | Student dashboard page |
| GET | /api/student/profile | Get student profile |
| PUT | /api/student/profile | Update student profile |
| GET | /api/student/applications | Get all student applications |
| POST | /api/student/applications | Apply for an opportunity |
| GET | /api/student/saved-opportunities | Get saved opportunities |
| POST | /api/student/saved-opportunities | Save an opportunity |
| DELETE | /api/student/saved-opportunities/:oppId | Remove saved opportunity |
| GET | /api/opportunities | Browse all active opportunities |
| GET | /near/me | Near Me map page |
| GET | /news/daily | Daily news page |
| GET | /careers/explore | Careers exploration page |
| GET | /api/news | Fetch news articles |
| GET | /api/books | Fetch career books |
| GET | /api/get-my-interests | Get RIASEC quiz results |
| POST | /api/save-interests | Save RIASEC quiz results |
| POST | /api/chat | Send message to AI career chatbot |
| POST | /api/generate-doc-from-chat | Generate AI career path document |
| GET | /api/saved-docs | Get list of saved career documents |
| GET | /api/saved-docs/:id | Get single saved document |
| GET | /logout | Clear JWT cookie and redirect |

### 6.3 Organisation Routes (JWT Required)

| Method | Endpoint | Description |
|---|---|---|
| GET | /org/dashboard | Org dashboard page |
| GET | /org/dashboard/applicants | Applicants page |
| GET | /org/dashboard/student-profile | Student profile view |
| GET | /org/analytics | Analytics page |
| GET | /org/dashboard/createOpportunity | Create opportunity page |
| POST | /api/opportunities/create | Create new opportunity |
| GET | /api/org/opportunities | Get organisation's own opportunities |
| PUT | /api/opportunities/:oppId | Update an opportunity |
| DELETE | /api/opportunities/:oppId | Delete an opportunity |
| GET | /api/org/applicants | Get applicants for org's opportunities |
| PATCH | /api/org/applicants/:appId/status | Update applicant status |
| GET | /api/org/dashboard-stats | Get dashboard statistics |

### 6.4 Admin Routes (JWT + requireAdmin Required)

| Method | Endpoint | Description |
|---|---|---|
| GET | /admin/dashboard | Admin dashboard page |
| GET | /admin/organisations | Get all organisations with stats |
| GET | /admin/organisations/:orgId | Get single organisation |
| PATCH | /admin/organisations/:orgId/approve | Approve organisation |
| PATCH | /admin/organisations/:orgId/reject | Reject organisation |
| DELETE | /admin/organisations/:orgId | Delete organisation |
| GET | /admin/students | Get all students |
| DELETE | /admin/students/:stuId | Delete student |

---

## 7. Authentication & Security

### 7.1 Authentication Flow

```
1. User submits login form (email, password, accountType)
2. Server looks up user in Student / Organisation / Admin table
3. bcrypt.compare() validates password hash
4. jwt.sign() creates token with { id, email, accountType }
5. Token stored in HTTP-only cookie (expires 7 days)
6. verifyToken middleware validates JWT on every protected route
7. req.user = decoded token payload (available in controllers)
```

### 7.2 Middleware

| Middleware | File | Purpose |
|---|---|---|
| `verifyToken` | sessionControllers.js | Validates JWT from HTTP-only cookie |
| `requireAdmin` | sessionControllers.js | Checks accountType === "admin" |
| `cookieParser` | main.js | Parses HTTP-only cookies |
| `express.json` | main.js | Parses JSON request bodies |

### 7.3 Security Measures

| Measure | Implementation |
|---|---|
| Password hashing | bcrypt with default salt rounds (10+) |
| Token-based auth | JWT (jsonwebtoken) stored in HTTP-only cookie |
| SQL injection prevention | Parameterised queries via mssql `.input()` |
| OTP verification | Time-limited one-time password via email |
| Environment secrets | All credentials in `.env` file (not committed to Git) |
| Admin access control | `requireAdmin` middleware checks JWT accountType |

---

## 8. External Integrations

### 8.1 Groq AI API

| Property | Value |
|---|---|
| Provider | Groq (https://groq.com) |
| Model | llama-3.3-70b-versatile |
| Purpose | AI career chatbot + career document generation |
| Max tokens (chat) | 1024 |
| Max tokens (document) | 2048 |
| Context | Student name, province, TopInterest from DB |
| SDK | groq-sdk npm package |

**Career Chatbot System Prompt (summary):**
> You are the SMILE Career Guide. Provide career, education, and professional development advice for South African students. Refuse off-topic queries. When suggesting careers, provide 3 South African options with required subjects, study duration, and ZAR salary range.

### 8.2 Nodemailer / Gmail SMTP

| Property | Value |
|---|---|
| Library | nodemailer |
| Service | Gmail |
| Auth | App password (environment variable) |
| Use cases | OTP verification, registration confirmation, password reset |

### 8.3 News API

| Property | Value |
|---|---|
| File | newsAPI.js |
| Purpose | Fetch daily South African news articles |
| Displayed on | news.html |

### 8.4 Careers/Jobs API

| Property | Value |
|---|---|
| File | careers.js |
| Purpose | Fetch live job listings |
| Displayed on | careers.html |

### 8.5 Books API

| Property | Value |
|---|---|
| File | booksAPI.js |
| Purpose | Fetch career-related books |
| Displayed on | studentdashboard.html |

### 8.6 Geocoding API (geoHelper.js)

| Property | Value |
|---|---|
| File | geoHelper.js |
| Purpose | Convert address/province to Lat/Lng coordinates |
| Triggered by | createNewOpportunity controller |
| Stored in | Opportunities.Lat, Opportunities.Lng |
| Used by | nearme.html map view |

---

## 9. Feature Modules

### 9.1 Registration & OTP Verification

**Flow:**
1. Student/Org fills registration form
2. Client-side: POST `/api/send-otp` → OTP sent to email
3. User enters OTP → POST `/api/verify-otp` → verified
4. On OTP success: POST `/register/student` or `/register/organization`
5. Password hashed with bcrypt before INSERT to DB
6. Organisation status set to `Pending` by default

### 9.2 Opportunity Lifecycle

```
Organisation creates → Status: Active → Students browse/apply
                    ↓
Organisation can edit (PUT) / delete (DELETE)
                    ↓
Applicant status flow: Pending → Reviewed → Shortlisted → Rejected
```

### 9.3 AI Career Counselling Module

**chatbotController.js handles:**
- `getCareerAdvice` — processes chat messages with full conversation history context
- `generateDocFromChat` — generates a structured career document and saves to DB
- `getMyInterests` — retrieves student's RIASEC TopInterest
- `saveInterests` — upserts RIASEC scores and calculates TopInterest
- `getSavedDocs` — lists all saved career documents for the student
- `getSingleDoc` — retrieves a specific saved document

**RIASEC Categories:**
| Code | Category | Traits |
|---|---|---|
| R | Realistic | Hands-on, mechanical, technical |
| I | Investigative | Analytical, scientific, research |
| A | Artistic | Creative, expressive, design |
| S | Social | Helping, teaching, counselling |
| E | Enterprising | Leadership, business, sales |
| C | Conventional | Organized, data, administration |

### 9.4 Near Me Map Feature

- Uses Leaflet.js or Google Maps on nearme.html
- Opportunities with valid Lat/Lng are plotted as map markers
- geoHelper.js converts address strings to coordinates during opportunity creation
- Stored as DECIMAL(9,6) in the Opportunities table

### 9.5 Admin Moderation Workflow

```
Organisation registers (Status: Pending)
        ↓
Admin sees pending org in Admin Dashboard
        ↓
Admin approves → Status: Active (org can now post opportunities)
           OR
Admin rejects → Status: Rejected (org cannot access features)
           OR
Admin deletes → Record removed (cascades to all opportunities)
```

---

## 10. SDLC Documentation

### 10.1 Software Development Life Cycle Model Used

**Model:** Agile (Iterative Sprints)

SMILE was developed using an Agile approach with iterative feature delivery. Each sprint produced working features that were tested and refined.

### 10.2 Phase 1: Planning

| Activity | Details |
|---|---|
| Project scoping | Identified core problem: SA students lack access to opportunity discovery and career guidance |
| Stakeholder identification | Students (primary users), Organisations (opportunity providers), Admins (platform moderators) |
| Technology selection | Node.js/Express, MS SQL Server, Groq AI, Nodemailer |
| Team | Lucas Bohani Maluleke (backend/DB lead) & Darren Foster (frontend/integration) |
| Version control | Git (repository: SMILE-1) |
| Environment setup | VS Code, nodemon, SQL Server Express, ODBC Driver 18 |

**Planning Deliverables:**
- Project proposal
- Stakeholder analysis
- Technology stack decision
- Project timeline and sprint planning

### 10.3 Phase 2: Requirements Analysis

| Activity | Details |
|---|---|
| Functional requirements gathering | Interviews with target users (students, NGOs) |
| Non-functional requirements | Performance, security, usability targets defined |
| Use case identification | 26 use cases identified across 4 actors |
| Entity identification | 9 database entities scoped |
| Risk analysis | Identified risks: AI API downtime, email delivery failures, DB connectivity |

**Requirements Deliverables:**
- Functional requirements list (FR-01 to FR-14)
- Non-functional requirements (NFR-01 to NFR-06)
- Use case diagram
- Initial ERD sketch

### 10.4 Phase 3: System Design

| Activity | Details |
|---|---|
| Architecture design | 3-tier MVC architecture selected |
| Database design | 9 tables designed with full normalisation (3NF) |
| API design | RESTful API with 40+ endpoints across user/admin routes |
| Security design | JWT + bcrypt + OTP verification selected |
| UI/UX design | Wireframes created for all 17 pages |
| External API selection | Groq AI, Nodemailer, News/Jobs/Books/Geo APIs selected |

**Design Deliverables:**
- System architecture diagram (draw.io)
- ERD (draw.io)
- Use case diagram (draw.io)
- Actor diagrams (draw.io)
- API endpoint specification

### 10.5 Phase 4: Implementation

**Sprint Breakdown:**

| Sprint | Features Delivered |
|---|---|
| Sprint 1 | Project scaffolding, DB schema, basic routing, Student/Org registration |
| Sprint 2 | Login (JWT auth), session management, page controllers, static file serving |
| Sprint 3 | Opportunity CRUD, Applications system, Organisation dashboard |
| Sprint 4 | Admin dashboard, moderation workflows, OTP verification |
| Sprint 5 | RIASEC quiz, AI chatbot integration (Groq), career document generation |
| Sprint 6 | Near Me map (geo-coding), News/Books/Jobs API integrations |
| Sprint 7 | Student profile, analytics, password reset, bug fixes |
| Sprint 8 | Saved opportunities, feedback, final UI polish, documentation |

**Implementation Standards:**
- ES Modules (`type: "module"` in package.json)
- Parameterised SQL queries (no raw string concatenation)
- bcrypt for all passwords before storage
- All secrets in `.env` (never committed)
- Comments and author attribution on all files

### 10.6 Phase 5: Testing

| Test Type | Method | Status |
|---|---|---|
| Unit Testing | Manual endpoint testing via browser / Postman | Completed |
| Integration Testing | End-to-end flows: Register → Login → Apply | Completed |
| Security Testing | JWT validation, admin-only route checks | Completed |
| User Acceptance Testing | Demo with student and organisation test accounts | Completed |
| Cross-browser Testing | Chrome, Edge, Firefox | Completed |

**Test Scenarios Covered:**
- ✅ Student registration with OTP verification
- ✅ Organisation registration (pending status)
- ✅ Student login → JWT cookie → dashboard access
- ✅ Admin login via org login card
- ✅ Create opportunity with geo-coding
- ✅ Student apply for opportunity (unique constraint)
- ✅ Admin approve/reject organisation
- ✅ RIASEC quiz save + AI chatbot with interest context
- ✅ Password reset via email link
- ✅ Logout clears HTTP-only cookie

### 10.7 Phase 6: Deployment

| Activity | Detail |
|---|---|
| Server | Node.js `npm run dev` (nodemon, port 3000) |
| Database | MS SQL Server Express (local / on-premises) |
| Connection | ODBC Driver 18, Windows Trusted_Connection |
| Entry point | `src/server/main.js` |
| Static files | Served by Express from `src/frontEnd/` |
| Environment | `.env` file with DB credentials, JWT secret, API keys |

### 10.8 Phase 7: Maintenance

| Activity | Plan |
|---|---|
| Bug fixes | GitHub issues tracking |
| Feature additions | New sprint planning |
| Database updates | Migration scripts in `/sql` directory |
| Monitoring | Console logs (planned: structured logging) |
| Backup | SQL Server backup procedures |

---

## 11. Database Life Cycle (DBLC)

### 11.1 DBLC Overview

The Database Life Cycle (DBLC) describes the stages the SMILE database went through from conception to production.

### 11.2 Stage 1: Database Planning

| Activity | Decision |
|---|---|
| DBMS Selection | Microsoft SQL Server Express (free, Windows-integrated, ODBC support) |
| Authentication | Windows Trusted_Connection (no separate SQL login needed) |
| Database Name | SMILE |
| File location | Default SQL Server data directory |
| Naming conventions | PascalCase for tables, PK named as TableName+ID |

### 11.3 Stage 2: Requirements Definition

**Data requirements identified:**
- User accounts (Students, Organisations, Admins)
- Opportunity postings with location data
- Application tracking with status workflow
- Student personality assessment (RIASEC)
- AI-generated document storage
- Feedback and ratings
- Bookmarked opportunities

### 11.4 Stage 3: Conceptual Design

**Entity identification:**

| Entity | Type | Key Attributes |
|---|---|---|
| Student | Strong entity | ID, name, email, province, education |
| Organisation | Strong entity | ID, name, email, type, status |
| Admin | Strong entity | ID, name, email |
| Opportunity | Strong entity | ID, title, type, location, deadline |
| Application | Weak entity (junction) | AppID, OppID, StuID, status |
| Feedback | Weak entity | FeedbackID, OppID, StuID, rating |
| StudentInterests | Weak entity | InterestID, StuID, RIASEC scores |
| SavedCareerDocs | Weak entity | DocID, StuID, content |
| SavedOpportunities | Junction/Weak | SaveID, StuID, OppID |

### 11.5 Stage 4: Logical Design

**Normalisation applied:**

**1NF (First Normal Form):**
- All tables have atomic values (no multi-value columns)
- All columns are single-valued (e.g., RIASEC scores stored as separate INT columns)

**2NF (Second Normal Form):**
- All non-key attributes are fully functionally dependent on the PK
- Applications table: Status and DateApplied depend on AppID, not just OppID or StuID alone

**3NF (Third Normal Form):**
- No transitive dependencies
- Organisation province is stored directly, not via a Province lookup table (design decision for simplicity)
- TopInterest in StudentInterests is derived (calculated from RIASEC scores) but stored for performance

**Key Design Decisions:**
- `UNIQUE(OppID, StuID)` in Applications — prevents duplicate applications
- `UNIQUE(StuID)` in StudentInterests — enforces one quiz result per student
- `UNIQUE(StuID, OppID)` in SavedOpportunities — prevents duplicate bookmarks
- `ON DELETE CASCADE` on all FK constraints — orphan record prevention

### 11.6 Stage 5: Physical Design

**SQL Server-specific implementations:**

| Feature | Implementation |
|---|---|
| Primary keys | IDENTITY(1,1) auto-increment |
| Timestamps | DEFAULT GETDATE() on all date columns |
| Text storage | VARCHAR(MAX) for descriptions; NVARCHAR(MAX) for Unicode content (AI docs) |
| Geo-coordinates | DECIMAL(9,6) for Lat/Lng (6 decimal places = ~10cm accuracy) |
| Status constraints | CHECK constraints on Organisation.Status and Feedback.Rating |
| Index strategy | Clustered indexes on all PKs; NONCLUSTERED on unique email columns |

**Database Configuration:**
- RECOVERY SIMPLE (minimised log file size for dev)
- AUTO_CLOSE ON (releases resources when not in use)
- COMPATIBILITY_LEVEL = 170 (SQL Server 2022)

### 11.7 Stage 6: Database Implementation

**Scripts created:**

| File | Purpose |
|---|---|
| smileScript.sql | Complete DB creation + all tables + constraints + seed |
| schema.sql | Initial Student and Organisation tables (early prototype) |
| createOppertunity.sql | Opportunities, Applications, Feedback tables |
| createSavedOpportunities.sql | SavedOpportunities table + FK constraints |
| Admin.sql | Admin table creation |
| seed.sql | Seed data for testing |
| stndProflile.sql | Profile-related queries |
| Org & Bot.sql | Org and chatbot-related queries |

**Connection Implementation (dbconnection.js):**
```javascript
const config = {
    connectionString: `Driver={ODBC Driver 18 for SQL Server};
                       Server=${process.env.LUCAS_SERVER_NAME};
                       Database=${process.env.DATABASE_NAME};
                       Trusted_Connection=yes;
                       Encrypt=no;TrustServerCertificate=yes`
};
```

### 11.8 Stage 7: Testing & Validation

| Test | Result |
|---|---|
| FK constraint cascade test | DELETE Organisation cascades to Opportunities → Applications/Feedback ✅ |
| UNIQUE constraint test | Duplicate application rejected with SQL UNIQUE violation ✅ |
| CHECK constraint test | Rating outside 1-5 rejected ✅ |
| Status constraint test | Invalid status string rejected ✅ |
| Connection pool test | Multiple concurrent requests handled correctly ✅ |
| Data type test | NVARCHAR stores Arabic/Unicode AI content correctly ✅ |

### 11.9 Stage 8: Maintenance & Evolution

| Version | Change | Date |
|---|---|---|
| v1.0 | Initial schema: Student, Organisation | March 2026 |
| v1.1 | Added Opportunities, Applications, Feedback tables | April 2026 |
| v1.2 | Added StudentInterests, SavedCareerDocs | April 2026 |
| v1.3 | Added SavedOpportunities, Admin table | April 2026 |
| v1.4 | Added StuBio, ProfilePicUrl to Student; Status to Organisation | May 2026 |
| v1.5 | Added Lat/Lng to Opportunities; updated smileScript.sql | May 2026 |

**Backup Strategy:**
- SQL Server Management Studio (SSMS) full database backup
- Scripts stored in `/src/server/sql/` directory (version-controlled in Git)

### 11.10 DBLC Summary Diagram

```
DBLC Stage Flow:

[1. Planning] → [2. Requirements] → [3. Conceptual Design (ERD)]
      ↓
[4. Logical Design (Normalisation)] → [5. Physical Design (SQL Server)]
      ↓
[6. Implementation (smileScript.sql)] → [7. Testing & Validation]
      ↓
[8. Maintenance (version evolution, backups)]
```

---

## 12. Deployment Guide

### 12.1 Prerequisites

```
- Node.js v18+
- MS SQL Server Express (local)
- ODBC Driver 18 for SQL Server
- Git
```

### 12.2 Installation Steps

```bash
# 1. Clone repository
git clone <repo-url>
cd SMILE-1

# 2. Install dependencies
npm install

# 3. Create .env file
# See .env template below

# 4. Create the database
# Run smileScript.sql in SSMS

# 5. Start the development server
npm run dev
# Server runs on http://localhost:3000
```

### 12.3 .env File Template

```
LUCAS_SERVER_NAME=YOUR_SERVER_NAME\SQLEXPRESS
DATABASE_NAME=SMILE
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=7d
LUCAS_EMAIL=your_gmail@gmail.com
LUCAS_APP_PASS=your_gmail_app_password
GROQ_API_KEY=your_groq_api_key
```

---

## 13. Testing

### 13.1 Manual Test Cases

| TC-ID | Test Case | Expected | Status |
|---|---|---|---|
| TC-01 | Register student with valid data | 201 response, OTP email sent | ✅ Pass |
| TC-02 | Register student with duplicate email | 409 conflict | ✅ Pass |
| TC-03 | Login with correct credentials | JWT cookie set, redirect to dashboard | ✅ Pass |
| TC-04 | Login with wrong password | 401 response | ✅ Pass |
| TC-05 | Access protected route without token | Redirect to login | ✅ Pass |
| TC-06 | Apply for opportunity twice | UNIQUE constraint error | ✅ Pass |
| TC-07 | Admin approve organisation | Status changes to Active | ✅ Pass |
| TC-08 | Organisation login before approval | Access limited | ✅ Pass |
| TC-09 | Create opportunity with address | Lat/Lng stored in DB | ✅ Pass |
| TC-10 | AI chat without RIASEC quiz | 400 response, prompt to complete quiz | ✅ Pass |

---

## 14. Known Issues & Future Work

### 14.1 Known Issues

| Issue | Description | Priority |
|---|---|---|
| Email delivery | Gmail SMTP may fail with app password expiry | Medium |
| Geo-coding | If address is ambiguous, coordinates may be inaccurate | Low |
| AI latency | Groq API response time varies (1–5 seconds) | Low |
| Session persistence | JWT cookie lost on browser data clear | Low |

### 14.2 Future Enhancements

| Feature | Description |
|---|---|
| Email notifications | Notify students when application status changes |
| Push notifications | Real-time browser notifications |
| File uploads | Resume/CV upload for applications |
| Mobile app | React Native mobile client |
| Advanced analytics | Organisation analytics dashboard with charts |
| Search ranking | AI-powered opportunity ranking based on student profile |
| Leaderboard | Student engagement and activity scoring |
| Multi-language | Afrikaans and other SA language support |
| Production deployment | Cloud hosting (Azure / Heroku) |
| Automated testing | Jest/Mocha unit and integration test suite |
