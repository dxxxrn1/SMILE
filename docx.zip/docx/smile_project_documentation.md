# Project Documentation: SMILE Portal
> [!NOTE]
> **Slogan:** "No Child is Left Behind"  
> **Target Audience:** South African youth, community organisations, and education administrators.  
> **Core Mission:** Empowering youth by connecting them with life-changing opportunities, career-path counseling, location-based services, and educational resources.

---

## 1. Project Overview & Context

**SMILE** is a multi-tier, database-driven web application designed to bridge the opportunity gap for South African youth. In South Africa, young people frequently struggle to find localized volunteering, skills development, internships, and mentoring options. Meanwhile, non-profit organisations (NGOs) and community initiatives face hurdles in reaching their target demographic and managing application flows.

SMILE acts as a centralized ecosystem that connects three primary user segments:
1. **Students (Youth):** Seeking personal growth, career advice, daily updates, near-me maps, and application status checks.
2. **Organisations (NGOs/Companies):** Seeking to post opportunities, manage applicant queues, map coordinates, and analyze outreach statistics.
3. **Administrators:** Responsible for verifying and onboarding legitimate organisations and moderating platform standards.

---

## 2. System Development Lifecycle (SDLC)
For a school documentation project, the **System Development Lifecycle (SDLC)** is crucial. The SMILE platform utilizes an **Agile/Iterative Methodology** to ensure user feedback loops, rapid prototyping, and high system flexibility. 

Below is how the SDLC translates directly into the building of the SMILE portal:

```mermaid
graph TD
    A[1. Planning & Feasibility] --> B[2. Requirements Analysis]
    B --> C[3. System Architecture & DB Design]
    C --> D[4. Implementation / Coding]
    D --> E[5. Verification & Testing]
    E --> F[6. Deployment & Maintenance]
    F -->|Feedback Loop| B
```

### SDLC Phases Applied to SMILE:

#### Phase 1: Planning & Scope
*   **Problem Statement:** South African youth, particularly from underrepresented communities, face structural hurdles in accessing career paths, skills training, and local volunteering.
*   **SMILE Solution:** A responsive portal with location-based search, AI-driven career guidance, and organisation verification.
*   **Feasibility:** Using lightweight Express.js middleware, Microsoft SQL Server for robust data transactions, and external APIs (Groq, Google/OpenStreetMap, job and news aggregators) to build a powerful service footprint.

#### Phase 2: Requirements Analysis
*   **Functional Requirements:**
    *   Secure dual-role registration (Students and Organisations) and administrative review.
    *   AI Chatbot integration utilizing Groq SDK to give interactive Holland Code (RIASEC) interest-based career suggestions.
    *   Interactive maps ("Near Me") that capture Lat/Lng database coordinates and show local volunteering opportunities.
    *   Organisation Dashboard with full CRUD capabilities over opportunities, application processing (Pending/Approve/Reject), and charts representing applicant telemetry.
*   **Non-Functional Requirements:**
    *   **Security:** Password hashing using `bcrypt` and state representation via token-based sessions using signed cookies (`jsonwebtoken`).
    *   **Scalability:** Normalized database architecture with referential integrity constraints to protect transaction history.

#### Phase 3: System Architecture & Database Design
*   **UI/UX Layout:** Clean, accessible layouts built with structured HTML5, Vanilla CSS, and client-side JavaScript supporting responsive sidebars and analytic displays.
*   **Database Schema:** Normalization to 3NF (Third Normal Form) ensuring that student data, interest assessments, opportunity listings, applications, feedback reports, and admin logging tables are structurally decoupled. (See Section 5 for the full ERD).

#### Phase 4: Implementation (Coding)
*   **Backend:** Express.js routing supporting RESTful API design.
*   **Database Integration:** MS SQL Server (`mssql` / `msnodesqlv8`) driver implementation utilizing parameterized queries to prevent SQL Injection vulnerabilities.
*   **AI Engine:** Direct integration with Groq API via standard SDKs.

#### Phase 5: Verification & Testing
*   **Unit & Integration Testing:** Custom routing tests ensuring token validation routines filter unauthorized client requests.
*   **Data Validation Checkpoints:** Enforcing check constraints (such as opportunity feedback ratings bound strictly to `[1, 5]`) and status codes limited to `('Pending', 'Active', 'Rejected')`.

#### Phase 6: Deployment & Maintenance
*   **Release Environment:** Host configuration running locally via Express server routines and Microsoft SQL server engine, easily packageable for Cloud deployment (e.g., Azure App Service + Azure SQL Database).

---

## 3. Technology Stack Architecture

SMILE is built on a modern, decoupled **Model-View-Controller (MVC)** architectural pattern:

```
                  +-----------------------------------+
                  |          USER INTERFACE           |
                  |  HTML5 / CSS3 / JavaScript Client |
                  +-----------------+-----------------+
                                    |
                                    | HTTP Requests (JSON / REST API)
                                    v
                  +-----------------------------------+
                  |          EXPRESS.JS SERVER        |
                  |     (Routing & Business Logic)    |
                  +-------+--------------------+------+
                          |                    |
            SQL Driver    |                    | Groq SDK / HTTP Fetch
            (msnodesqlv8) |                    |
                          v                    v
     +--------------------+---------+   +------+----------------------+
     |          DATABASE            |   |       EXTERNAL SERVICES     |
     |   Microsoft SQL Server 2017+ |   | - Groq AI Engine (Chat)     |
     |     (SMILE Schema in 3NF)    |   | - News API / Jobs API       |
     +------------------------------+   | - OpenStreetMap / Leaflet   |
                                        +-----------------------------+
```

*   **Front-End Component:** HTML5 Semantic Layouts, styled with Vanilla CSS3 variables, and vanilla JS handles asynchronous client actions (`fetch` APIs, dynamic map rendering, interactive analytical charts).
*   **Back-End Core:** Node.js + Express.js. Implements page routing, JSON API endpoints, password recovery workflows (via `nodemailer`), and JWT token validation.
*   **Database Engine:** Microsoft SQL Server. Utilizes strict referential integrity, foreign key cascades, and transactional safety hooks.
*   **AI Integration:** Groq SDK facilitating real-time interactions with high-performance LLMs (Large Language Models) to deliver responsive career coaching.

---

## 4. UML Actors & Use Case Diagrams

### Platform Actors Defined:
1.  **Student (Youth Actor):** A registered young user who completes interests surveys, browses and saves local opportunities, tracks applications, and consults the AI career counselor.
2.  **Organisation (NGO/Company Actor):** An enterprise-tier actor who posts opportunities, maps coordinates, reviews candidates, and visualizes applicant metrics.
3.  **Administrator (Moderation Actor):** The supervisor who manages organization verification requests, maintains community safety, and removes malicious accounts.
4.  **External Services (System Actor):** The Map service (Leaflet/OSM), Groq AI Chat API, Books API, and Jobs API.

### Use Case Diagram (System Interactions)

```mermaid
useCaseDiagram
    rect Client-Side-Portals
        actor Student as "Student (Youth)"
        actor Org as "Organisation"
        actor Admin as "Administrator"
        actor External as "External APIs / AI System"
    end

    rect Use-Cases
        usecase UC1 as "Register / Login"
        usecase UC2 as "Browse & Save Opportunities"
        usecase UC3 as "Apply for Opportunity"
        usecase UC4 as "View Opportunities Near Me (Map)"
        usecase UC5 as "Take Holland Code Interest Test"
        usecase UC6 as "Chat with AI Career Coach"
        usecase UC7 as "Post & Manage Opportunities"
        usecase UC8 as "Review Applicants & Manage Status"
        usecase UC9 as "View Org Metrics & Analytics"
        usecase UC10 as "Approve/Reject Pending Orgs"
        usecase UC11 as "Moderate & Delete Accounts"
    end

    Student --> UC1
    Student --> UC2
    Student --> UC3
    Student --> UC4
    Student --> UC5
    Student --> UC6

    Org --> UC1
    Org --> UC7
    Org --> UC8
    Org --> UC9

    Admin --> UC1
    Admin --> UC10
    Admin --> UC11

    UC4 --> External
    UC6 --> External
```

---

## 5. Entity-Relationship Diagram (ERD)

The SMILE database schema is fully normalized and organized around the SQL Server database schema rules. Relationships utilize cascading deletes to prevent orphaned entries in application history.

### Database ERD (Entity-Relationship Diagram)

```mermaid
erDiagram
    Organisation ||--o{ Opportunities : "posts"
    Student ||--o{ Applications : "submits"
    Student ||--o{ Feedback : "provides"
    Student ||--o| StudentInterests : "assesses"
    Student ||--o{ SavedCareerDocs : "saves"
    Opportunities ||--o{ Applications : "receives"
    Opportunities ||--o{ Feedback : "receives"

    Organisation {
        int OrgId PK
        varchar OrgName
        varchar OrgEmail UK
        varchar Type
        varchar Province
        varchar Password
        varchar Status "Pending / Active / Rejected"
        datetime DateCreated
    }

    Student {
        int StuID PK
        varchar StuName
        varchar StuLastName
        varchar StuEmail UK
        varchar StuProvince
        varchar StuEducationLevel
        varchar StuPassword
        nvarchar StuBio
        nvarchar ProfilePicUrl
        datetime DateCreated
    }

    Opportunities {
        int OppID PK
        int OrgId FK
        varchar Title
        varchar OppType
        varchar Province
        varchar Description
        varchar Requirements
        varchar ApplicationLink
        int MaxApplicants
        date ApplicationDeadline
        date StartDate
        varchar Status "Active / Closed"
        decimal Lat
        decimal Lng
        datetime DateCreated
    }

    Applications {
        int AppID PK
        int OppID FK
        int StuID FK
        varchar Status "Pending / Approved / Rejected"
        datetime DateApplied
    }

    Feedback {
        int FeedbackID PK
        int OppID FK
        int StuID FK
        int Rating "1 to 5"
        varchar Comment
        datetime DateSubmitted
    }

    StudentInterests {
        int InterestID PK
        int StuID FK-UK
        int Realistic
        int Investigative
        int Artistic
        int Social
        int Enterprising
        int Conventional
        varchar TopInterest
        datetime DateTaken
    }

    SavedCareerDocs {
        int DocID PK
        int StuID FK
        varchar CareerTitle
        nvarchar DocContent
        datetime DateSaved
    }

    Admin {
        int AdminID PK
        varchar AdminName
        varchar AdminEmail UK
        varchar AdminPassword
        datetime CreatedAt
    }
```

### Table Relationships Mapping:
*   **Organisation to Opportunities (1:N):** An organisation can list multiple volunteering or training options, but each listing belongs to a single organisation.
*   **Student to Applications (1:N):** A student can apply to multiple opportunities.
*   **Opportunities to Applications (1:N):** An opportunity can attract multiple applicants.
*   **Student to StudentInterests (1:1):** A student has exactly one record mapping their latest Holland Code personality results.
*   **Student to SavedCareerDocs (1:N):** A student can store multiple career advice articles or generated cover letters from the AI Chatbot workspace.

---

## 6. Functional Capabilities Summarized

### I. Student Career & Opportunities Engine
*   **Holland Codes (RIASEC) Model:** Students complete an internal survey assessing interests across Realistic, Investigative, Artistic, Social, Enterprising, and Conventional categories.
*   **Interactive Spatial Intelligence:** Map integrations load database coordinate offsets (`Lat`, `Lng`) onto Leaflet maps, instantly helping youth find opportunities within walking range.
*   **Job & Book Scrapers:** Custom server integrations fetch real-time careers listings and educational textbooks, giving students resources without leaving the platform.

### II. Corporate & NGO Admin Dashboard
*   **Telemetry & Metrics:** High-level dashboard displays calculations for pending applicants, active postings, and aggregate success ratings.
*   **Applicant Funnel Management:** Organisations can view candidate portfolios, read student biographies, inspect interest levels, and update state models (`Pending -> Approved/Rejected`) with a single click.

### III. System Trust & Security
*   **Onboarding Verification:** Organisations are locked from posting opportunities until a platform Administrator manually audits and changes status from `Pending` to `Active`.
*   **Transaction Integrity:** Foreign key structures enforce complete referential checks: deleting a student automatically scrubs linked application attempts, preventing index degradation in SQL Server.
