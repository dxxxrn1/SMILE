# SMILE Use Case Diagram — draw.io XML

## Actors
| Actor | Description |
|---|---|
| **Guest** | Unauthenticated visitor to the site |
| **Student** | Registered student user |
| **Organisation** | Registered NGO/Company posting opportunities |
| **Admin** | Platform administrator |
| **Groq AI System** | External AI service (automated actor) |
| **Email System** | Nodemailer/Gmail SMTP (automated actor) |

---

## Use Case Diagram XML — paste into draw.io

```xml
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- TITLE -->
    <mxCell id="title" value="SMILE – Use Case Diagram" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=18;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="550" y="20" width="400" height="40" as="geometry" />
    </mxCell>

    <!-- SYSTEM BOUNDARY -->
    <mxCell id="sys" value="SMILE System" style="points=[[0,0],[0.25,0],[0.5,0],[0.75,0],[1,0],[1,0.25],[1,0.5],[1,0.75],[1,1],[0.75,1],[0.5,1],[0.25,1],[0,1],[0,0.75],[0,0.5],[0,0.25]];shape=mxgraph.flowchart.start_2;fillColor=none;strokeColor=#000000;strokeWidth=2;fontSize=14;fontStyle=1;verticalAlign=top;" vertex="1" parent="1">
      <mxGeometry x="220" y="80" width="1000" height="1000" as="geometry" />
    </mxCell>
    <mxCell id="syslabel" value="&lt;&lt;System&gt;&gt; SMILE Platform" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=14;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="500" y="90" width="400" height="30" as="geometry" />
    </mxCell>

    <!-- ======= ACTORS (LEFT) ======= -->
    <!-- Guest -->
    <mxCell id="guest" value="Guest" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#666666;fontColor=#333333;" vertex="1" parent="1">
      <mxGeometry x="40" y="140" width="60" height="80" as="geometry" />
    </mxCell>
    <!-- Student -->
    <mxCell id="student" value="Student" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="40" y="340" width="60" height="80" as="geometry" />
    </mxCell>
    <!-- Organisation -->
    <mxCell id="org" value="Organisation" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="40" y="620" width="60" height="80" as="geometry" />
    </mxCell>
    <!-- Admin -->
    <mxCell id="admin" value="Admin" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="40" y="870" width="60" height="80" as="geometry" />
    </mxCell>

    <!-- ======= ACTORS (RIGHT) ======= -->
    <!-- Groq AI -->
    <mxCell id="ai" value="Groq AI&#xa;System" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
      <mxGeometry x="1370" y="500" width="60" height="80" as="geometry" />
    </mxCell>
    <!-- Email System -->
    <mxCell id="email" value="Email&#xa;System" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="1370" y="200" width="60" height="80" as="geometry" />
    </mxCell>

    <!-- ======= USE CASES ======= -->

    <!-- UC1: View Home Page -->
    <mxCell id="uc1" value="View Home Page" style="ellipse;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
      <mxGeometry x="280" y="150" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC2: Register as Student -->
    <mxCell id="uc2" value="Register as Student" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="280" y="230" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC3: Register as Organisation -->
    <mxCell id="uc3" value="Register as Organisation" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="280" y="310" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC4: Verify OTP -->
    <mxCell id="uc4" value="Verify OTP Email" style="ellipse;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="500" y="230" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC5: Login -->
    <mxCell id="uc5" value="Login" style="ellipse;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
      <mxGeometry x="280" y="390" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC6: Forgot / Reset Password -->
    <mxCell id="uc6" value="Forgot / Reset Password" style="ellipse;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
      <mxGeometry x="500" y="390" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC7: View/Update Student Profile -->
    <mxCell id="uc7" value="View / Update Profile" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="280" y="470" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC8: Browse Opportunities -->
    <mxCell id="uc8" value="Browse Opportunities" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="500" y="470" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC9: Apply for Opportunity -->
    <mxCell id="uc9" value="Apply for Opportunity" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="720" y="470" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC10: Save Opportunity -->
    <mxCell id="uc10" value="Save Opportunity" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="720" y="540" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC11: View Near Me Map -->
    <mxCell id="uc11" value="View Opportunities Near Me" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="500" y="540" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC12: Take Interest Quiz -->
    <mxCell id="uc12" value="Take RIASEC Interest Quiz" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="280" y="560" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC13: Chat with AI Career Bot -->
    <mxCell id="uc13" value="Chat with AI Career Bot" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="940" y="500" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC14: Generate Career Doc -->
    <mxCell id="uc14" value="Generate Career Path Doc" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="940" y="570" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC15: View News -->
    <mxCell id="uc15" value="Read Daily News" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="280" y="640" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC16: Explore Careers -->
    <mxCell id="uc16" value="Explore Career Listings" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="500" y="640" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC17: Logout -->
    <mxCell id="uc17" value="Logout" style="ellipse;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
      <mxGeometry x="720" y="640" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- === ORG USE CASES === -->
    <!-- UC18: Create Opportunity -->
    <mxCell id="uc18" value="Create Opportunity" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="280" y="720" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC19: Edit / Delete Opportunity -->
    <mxCell id="uc19" value="Edit / Delete Opportunity" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="500" y="720" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC20: View Applicants -->
    <mxCell id="uc20" value="View Applicants" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="720" y="720" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC21: Update Applicant Status -->
    <mxCell id="uc21" value="Update Applicant Status" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="940" y="720" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC22: View Org Analytics -->
    <mxCell id="uc22" value="View Dashboard Analytics" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="280" y="800" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- === ADMIN USE CASES === -->
    <!-- UC23: View Admin Dashboard -->
    <mxCell id="uc23" value="Access Admin Dashboard" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="280" y="900" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- UC24: Approve/Reject Organisation -->
    <mxCell id="uc24" value="Approve / Reject Organisation" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="500" y="900" width="180" height="50" as="geometry" />
    </mxCell>

    <!-- UC25: Delete Organisation / Student -->
    <mxCell id="uc25" value="Delete Organisation / Student" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="720" y="900" width="180" height="50" as="geometry" />
    </mxCell>

    <!-- UC26: View All Users -->
    <mxCell id="uc26" value="View All Users" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="940" y="900" width="160" height="50" as="geometry" />
    </mxCell>

    <!-- ======= ASSOCIATIONS ======= -->

    <!-- Guest associations -->
    <mxCell id="e1" style="edgeStyle=none;html=1;" edge="1" source="guest" target="uc1" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e2" style="edgeStyle=none;html=1;" edge="1" source="guest" target="uc2" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e3" style="edgeStyle=none;html=1;" edge="1" source="guest" target="uc3" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e4" style="edgeStyle=none;html=1;" edge="1" source="guest" target="uc5" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- Student associations -->
    <mxCell id="e5" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc7" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e6" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc8" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e7" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc9" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e8" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc10" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e9" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc11" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e10" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc12" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e11" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc13" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e12" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc14" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e13" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc15" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e14" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc16" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e15" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc17" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e16" style="edgeStyle=none;html=1;" edge="1" source="student" target="uc6" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- Org associations -->
    <mxCell id="e17" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc18" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e18" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc19" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e19" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc20" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e20" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc21" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e21" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc22" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e22" style="edgeStyle=none;html=1;" edge="1" source="org" target="uc17" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- Admin associations -->
    <mxCell id="e23" style="edgeStyle=none;html=1;" edge="1" source="admin" target="uc23" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e24" style="edgeStyle=none;html=1;" edge="1" source="admin" target="uc24" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e25" style="edgeStyle=none;html=1;" edge="1" source="admin" target="uc25" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e26" style="edgeStyle=none;html=1;" edge="1" source="admin" target="uc26" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- AI Actor associations -->
    <mxCell id="e27" style="edgeStyle=none;html=1;" edge="1" source="ai" target="uc13" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e28" style="edgeStyle=none;html=1;" edge="1" source="ai" target="uc14" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- Email Actor associations -->
    <mxCell id="e29" style="edgeStyle=none;html=1;" edge="1" source="email" target="uc4" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e30" style="edgeStyle=none;html=1;" edge="1" source="email" target="uc6" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="e31" style="edgeStyle=none;html=1;" edge="1" source="email" target="uc3" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

    <!-- Include relationships -->
    <mxCell id="inc1" value="&lt;&lt;include&gt;&gt;" style="edgeStyle=none;html=1;dashed=1;endArrow=open;" edge="1" source="uc2" target="uc4" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="inc2" value="&lt;&lt;include&gt;&gt;" style="edgeStyle=none;html=1;dashed=1;endArrow=open;" edge="1" source="uc9" target="uc5" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="inc3" value="&lt;&lt;include&gt;&gt;" style="edgeStyle=none;html=1;dashed=1;endArrow=open;" edge="1" source="uc13" target="uc12" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>
    <mxCell id="inc4" value="&lt;&lt;extend&gt;&gt;" style="edgeStyle=none;html=1;dashed=1;endArrow=open;" edge="1" source="uc14" target="uc13" parent="1"><mxGeometry relative="1" as="geometry" /></mxCell>

  </root>
</mxGraphModel>
```

---

## Use Case Descriptions

### UC-001: Register as Student
| Field | Detail |
|---|---|
| **Actor** | Guest |
| **Precondition** | User is not logged in |
| **Main Flow** | Fill registration form → Submit → OTP sent to email → Verify OTP → Account created |
| **Postcondition** | Student account created in DB |
| **Extensions** | OTP invalid → Re-send OTP |

### UC-002: Login
| Field | Detail |
|---|---|
| **Actor** | Student / Organisation / Admin |
| **Precondition** | Account exists |
| **Main Flow** | Enter email + password + account type → Server validates → JWT issued → Cookie set → Redirect to dashboard |
| **Postcondition** | Session active, token stored in HTTP-only cookie |

### UC-003: Browse & Apply for Opportunities
| Field | Detail |
|---|---|
| **Actor** | Student |
| **Precondition** | Student logged in |
| **Main Flow** | Navigate to opportunities page → Filter by type/province/search → View details → Apply |
| **Postcondition** | Application record created in Applications table |
| **Include** | Login (UC-002) |

### UC-004: Chat with AI Career Bot
| Field | Detail |
|---|---|
| **Actor** | Student, Groq AI System |
| **Precondition** | Student logged in and RIASEC quiz completed |
| **Main Flow** | Open career bot → Ask question → Request sent to Groq API → AI responds with career advice |
| **Postcondition** | Conversation stored client-side |
| **Extends** | Generate Career Path Document (UC-005) |

### UC-005: Manage Opportunities (Organisation)
| Field | Detail |
|---|---|
| **Actor** | Organisation |
| **Precondition** | Organisation logged in and approved by Admin |
| **Main Flow** | Go to Create Opportunity → Fill form → Geo-coding runs → Opportunity saved |
| **Postcondition** | Opportunity visible to students |

### UC-006: Approve Organisation (Admin)
| Field | Detail |
|---|---|
| **Actor** | Admin |
| **Precondition** | Admin logged in |
| **Main Flow** | Admin Dashboard → View pending organisations → Approve/Reject → Status updated |
| **Postcondition** | Organisation status changed in DB |
