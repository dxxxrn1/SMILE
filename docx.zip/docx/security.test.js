import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dns from 'dns';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// When located in docx, the root is one level up
const rootDir = path.dirname(__dirname);

// Premium Visual Reporting Console Styles
const colors = {
  reset: "\x1b[0m",
  bright: "\x1b[1m",
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  cyan: "\x1b[36m",
  magenta: "\x1b[35m",
  bgBlack: "\x1b[40m"
};

console.log(`\n${colors.cyan}${colors.bright}================================================================${colors.reset}`);
console.log(`${colors.magenta}${colors.bright}            SMILE PLATFORM - AUTOMATED SECURITY AUDIT           ${colors.reset}`);
console.log(`${colors.cyan}${colors.bright}================================================================${colors.reset}\n`);

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(description, condition, details = "") {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ${colors.green}✅ [PASS]${colors.reset} ${colors.bright}${description}${colors.reset}`);
    if (details) console.log(`           ${colors.green}→ ${details}${colors.reset}`);
  } else {
    failedTests++;
    console.log(`  ${colors.red}❌ [FAIL]${colors.reset} ${colors.bright}${description}${colors.reset}`);
    if (details) console.log(`           ${colors.red}→ WARNING: ${details}${colors.reset}`);
  }
}

// ==========================================
// TEST 1: ENVIRONMENT VARIABLES & SECRETS HARDCODING AUDIT
// ==========================================
console.log(`${colors.blue}${colors.bright}1. Environment Variables & Secrets Leak Scan${colors.reset}`);

// Read .env keys and values to build scanner blocklists
const dotenvPath = path.join(rootDir, '.env');
let envSecrets = {};
if (fs.existsSync(dotenvPath)) {
  const envContent = fs.readFileSync(dotenvPath, 'utf8');
  envContent.split(/\r?\n/).forEach(line => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return;
    const parts = trimmed.split('=');
    if (parts.length >= 2) {
      const key = parts[0].trim();
      const val = parts.slice(1).join('=').trim();
      // Only audit actual high-entropy secrets
      if (
        key.includes('PASSWORD') ||
        key.includes('SECRET') ||
        key.includes('PASS') ||
        key.includes('KEY') ||
        key.includes('TOKEN')
      ) {
        if (val.length > 5 && !val.startsWith('process.env')) {
          envSecrets[key] = val;
        }
      }
    }
  });
}

// Recursive scanner to search for plaintext hardcoded matches
function scanDirectoryForSecrets(dirPath, filesChecked = { count: 0 }, violations = []) {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      if (
        item === 'node_modules' ||
        item === '.git' ||
        item === '.vs' ||
        item === '.vscode' ||
        item === 'uploads'
      ) {
        continue;
      }
      scanDirectoryForSecrets(fullPath, filesChecked, violations);
    } else {
      const ext = path.extname(item).toLowerCase();
      if (['.js', '.html', '.css', '.config'].includes(ext)) {
        filesChecked.count++;
        const content = fs.readFileSync(fullPath, 'utf8');
        
        // Scan for plaintext matches of defined secrets in .env
        for (const [key, value] of Object.entries(envSecrets)) {
          if (content.includes(value) && !fullPath.endsWith('.env') && !fullPath.endsWith('security.test.js')) {
            violations.push({
              file: path.relative(rootDir, fullPath),
              secretKey: key,
              reason: 'Plaintext value matches environment configuration secret'
            });
          }
        }

        // Regex check for naive assignments like: password = "some_literal"
        const hardcodedPasswordRegex = /(?:password|passwd|api_key|jwt_secret|app_pass)\s*=\s*['"`]([A-Za-z0-9_#$@!%-]{6,})['"`]/gi;
        let match;
        while ((match = hardcodedPasswordRegex.exec(content)) !== null) {
          const literal = match[1];
          // Filter out typical safe configurations or imports
          if (
            literal !== 'password' &&
            literal !== 'undefined' &&
            literal !== 'null' &&
            !literal.startsWith('process.env')
          ) {
            violations.push({
              file: path.relative(rootDir, fullPath),
              secretKey: 'Hardcoded literal assignment pattern found',
              reason: `Suspected credential assignment: "${match[0].trim()}"`
            });
          }
        }
      }
    }
  }
  return { filesChecked, violations };
}

const scanResults = scanDirectoryForSecrets(path.join(rootDir, 'src'));
assert(
  `Plaintext Secrets Scanner (Checked ${scanResults.filesChecked.count} code files)`,
  scanResults.violations.length === 0,
  scanResults.violations.length > 0 
    ? `${scanResults.violations.length} secret leaks found!\n` + 
      scanResults.violations.map(v => `      - [${v.file}]: ${v.reason} (${v.secretKey})`).join('\n')
    : 'No plaintext database passwords, JWT secrets, or API keys are hardcoded in the codebase.'
);

// ==========================================
// TEST 2: GITIGNORE PROTECTION AUDIT
// ==========================================
console.log(`\n${colors.blue}${colors.bright}2. Git Leaks Prevention Check${colors.reset}`);
const gitignorePath = path.join(rootDir, '.gitignore');
let gitignoreProtected = false;

if (fs.existsSync(gitignorePath)) {
  const lines = fs.readFileSync(gitignorePath, 'utf8').split(/\r?\n/);
  gitignoreProtected = lines.some(line => {
    const trimmed = line.trim();
    return trimmed === '.env' || trimmed.startsWith('.env.') || trimmed.includes('.env');
  });
}

assert(
  "Git ignore rules for secrets (.env files)",
  gitignoreProtected,
  gitignoreProtected ? "'.env' is listed in gitignore." : "'.env' is exposed! Add '.env' to your gitignore."
);

// ==========================================
// INTEGRATION TESTS (REQUIRES RUNNING LOCAL SERVER)
// ==========================================
const BASE_URL = 'http://localhost:3000';

async function runNetworkTests() {
  console.log(`\n${colors.blue}${colors.bright}3. Live Endpoint Security Integration Audits${colors.reset}`);
  console.log(`   ${colors.yellow}Targeting Server: ${BASE_URL}${colors.reset}\n`);

  try {
    // Check if server is running by hitting home page
    const checkRes = await fetch(`${BASE_URL}/`, { method: 'GET' });
    if (!checkRes.ok && checkRes.status !== 302) {
      throw new Error(`Server returned status: ${checkRes.status}`);
    }
  } catch (err) {
    console.log(`  ${colors.red}⚠️  Local server at ${BASE_URL} is offline or unreachable.${colors.reset}`);
    console.log(`     Make sure the dev server is active (e.g. running 'npm run dev') to execute live route audits.`);
    console.log(`     Skipping network integration tests.`);
    reportSummary();
    process.exit(failedTests > 0 ? 1 : 0);
  }

  // A. Protected Route Access Checks
  const protectedRoutes = [
    { path: '/api/student/profile', name: 'Student Profile API' },
    { path: '/api/org/profile', name: 'Organisation Profile API' },
    { path: '/admin/dashboard', name: 'Admin Dashboard Page' },
    { path: '/admin/organisations', name: 'Admin Organisation Listing API' },
    { path: '/admin/api/tickets', name: 'Admin Support Tickets API' }
  ];

  for (const route of protectedRoutes) {
    try {
      const res = await fetch(`${BASE_URL}${route.path}`, {
        method: 'GET',
        redirect: 'manual' // Prevent following redirect to check 302/401/403 status codes
      });
      const isSecure = res.status === 302 || res.status === 401 || res.status === 403;
      assert(
        `Authorization Gate for route: ${route.path} (${route.name})`,
        isSecure,
        `Returned status ${res.status}. Expected redirection (302) or authorization denial (401/403).`
      );
    } catch (e) {
      assert(`Authorization Gate for route: ${route.path}`, false, `Network error: ${e.message}`);
    }
  }

  // B. CORS Header Checks
  try {
    const corsRes = await fetch(`${BASE_URL}/api/jobs`, {
      method: 'GET',
      headers: {
        'Origin': 'https://malicious-attacker.com'
      }
    });
    const allowOrigin = corsRes.headers.get('access-control-allow-origin');
    const isCorsSafe = !allowOrigin || (allowOrigin !== '*' && allowOrigin !== 'https://malicious-attacker.com');
    assert(
      "CORS Policy Verification against rogue origins",
      isCorsSafe,
      allowOrigin 
        ? `Exposed CORS origin: "${allowOrigin}". Ensure wildcard '*' or unvetted domains are restricted.`
        : "CORS headers are correctly locked down on internal endpoints."
    );
  } catch (e) {
    assert("CORS Verification", false, `Network error: ${e.message}`);
  }

  // C. Error Stack Trace Leak Audit
  try {
    // Send a malformed ID parameter to trigger potential casting errors or query failures
    const errorRes = await fetch(`${BASE_URL}/api/org/public-profile/invalid_id_format_test`, {
      method: 'GET'
    });
    const text = await errorRes.text();
    const hasStackTrace = text.includes('TypeError:') || text.includes('at ') || text.includes('node_modules') || text.includes('mssql');
    assert(
      "Information Disclosure & Production Stack Trace Leak check",
      !hasStackTrace,
      hasStackTrace 
        ? "Stack trace or driver exception leaked to response! Ensure environment variables suppress stack traces in production."
        : "Errors are handled gracefully without exposing server stack details."
    );
  } catch (e) {
    assert("Stack Trace Leak check", false, `Network error: ${e.message}`);
  }

  // D. SQL Injection Prevention check on login and registration endpoints
  try {
    const sqliPayload = {
      email: "' OR '1'='1' --",
      password: "password123",
      accountType: "student"
    };
    const sqliRes = await fetch(`${BASE_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(sqliPayload)
    });
    
    // SQL Injection must be rejected securely (returned unauthorized 401 or bad request 400)
    const isSqliSafe = sqliRes.status === 401 || sqliRes.status === 400;
    assert(
      "SQL Injection Auditor on student login endpoint",
      isSqliSafe,
      `Returned status ${sqliRes.status}. Expected 401/400. Parameterized query validation required.`
    );
  } catch (e) {
    assert("SQL Injection Auditor on student login endpoint", false, `Network error: ${e.message}`);
  }

  reportSummary();
}

function reportSummary() {
  console.log(`\n${colors.cyan}${colors.bright}================================================================${colors.reset}`);
  console.log(`${colors.magenta}${colors.bright}                     AUDIT RESULTS SUMMARY                      ${colors.reset}`);
  console.log(`${colors.cyan}${colors.bright}================================================================${colors.reset}\n`);

  console.log(`  Total Checks Executed:  ${colors.bright}${totalTests}${colors.reset}`);
  console.log(`  Passed Checks:         ${colors.green}${colors.bright}${passedTests}${colors.reset}`);
  console.log(`  Failed Checks:         ${failedTests > 0 ? colors.red : colors.green}${colors.bright}${failedTests}${colors.reset}`);
  
  if (failedTests === 0) {
    console.log(`\n  ${colors.green}${colors.bright}🎉 EXCELLENT! The application has PASSED all security audits successfully.${colors.reset}\n`);
  } else {
    console.log(`\n  ${colors.red}${colors.bright}⚠️  SECURITY WARNING: ${failedTests} checks failed. Correct the vulnerabilities immediately.${colors.reset}\n`);
  }
}

// Start live audits
runNetworkTests();
