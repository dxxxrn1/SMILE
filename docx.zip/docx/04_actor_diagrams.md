# SMILE Actor Diagrams

## System Actors Overview

SMILE has **4 human actors** and **2 system actors**. Each actor has a distinct role, access level, and set of permitted operations.

---

## Actor Diagram 1: All Actors Overview — draw.io XML

```xml
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- TITLE -->
    <mxCell id="title" value="SMILE – Actor Diagram" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=20;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="500" y="20" width="500" height="40" as="geometry" />
    </mxCell>

    <!-- ==================== GUEST ACTOR ==================== -->
    <mxCell id="guestBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#999999;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="60" y="120" width="280" height="320" as="geometry" />
    </mxCell>
    <mxCell id="guestTitle" value="&lt;b&gt;GUEST&lt;/b&gt;&#xa;(Unauthenticated Visitor)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="60" y="130" width="280" height="40" as="geometry" />
    </mxCell>
    <mxCell id="guestActor" value="Guest" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#666666;" vertex="1" parent="1">
      <mxGeometry x="170" y="180" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="guestPerms" value="✓ View Landing Page&#xa;✓ Register (Student/Org)&#xa;✓ Login&#xa;✓ Forgot Password&#xa;✗ All Protected Routes" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="75" y="280" width="250" height="140" as="geometry" />
    </mxCell>

    <!-- ==================== STUDENT ACTOR ==================== -->
    <mxCell id="stuBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="380" y="120" width="300" height="460" as="geometry" />
    </mxCell>
    <mxCell id="stuTitle" value="&lt;b&gt;STUDENT&lt;/b&gt;&#xa;(Registered &amp; Verified)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="380" y="130" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="stuActor" value="Student" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="500" y="180" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="stuPerms" value="✓ View/Update Profile&#xa;✓ Browse Opportunities&#xa;✓ Apply for Opportunity&#xa;✓ Save/Unsave Opportunity&#xa;✓ View Application Status&#xa;✓ View Near Me (Map)&#xa;✓ Read Daily News&#xa;✓ Explore Career Listings&#xa;✓ Take RIASEC Interest Quiz&#xa;✓ Chat with AI Career Bot&#xa;✓ Generate Career Path Document&#xa;✓ View Saved Career Docs&#xa;✓ Logout" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="390" y="275" width="275" height="290" as="geometry" />
    </mxCell>

    <!-- ==================== ORGANISATION ACTOR ==================== -->
    <mxCell id="orgBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="720" y="120" width="300" height="380" as="geometry" />
    </mxCell>
    <mxCell id="orgTitle" value="&lt;b&gt;ORGANISATION&lt;/b&gt;&#xa;(Approved by Admin)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="720" y="130" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="orgActor" value="Organisation" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="840" y="180" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="orgPerms" value="✓ Login / Logout&#xa;✓ Create Opportunity (with geo-coding)&#xa;✓ Edit / Update Opportunity&#xa;✓ Delete Opportunity&#xa;✓ View All Own Applicants&#xa;✓ Update Applicant Status&#xa;  (Pending→Shortlisted→Rejected)&#xa;✓ View Org Dashboard Stats&#xa;✓ View Analytics Page&#xa;✗ Browse Student Profiles directly" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="730" y="275" width="275" height="210" as="geometry" />
    </mxCell>

    <!-- ==================== ADMIN ACTOR ==================== -->
    <mxCell id="admBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="1060" y="120" width="300" height="320" as="geometry" />
    </mxCell>
    <mxCell id="admTitle" value="&lt;b&gt;ADMIN&lt;/b&gt;&#xa;(Super User — JWT accountType=admin)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="1060" y="130" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="admActor" value="Admin" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="1180" y="180" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="admPerms" value="✓ Login via Organisation Login Card&#xa;✓ View Admin Dashboard&#xa;✓ View All Organisations (stats)&#xa;✓ Approve Organisation&#xa;✓ Reject Organisation&#xa;✓ Delete Organisation&#xa;✓ View All Students&#xa;✓ Delete Student&#xa;✗ Organisation features" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="1070" y="275" width="275" height="150" as="geometry" />
    </mxCell>

    <!-- ==================== SYSTEM ACTORS ==================== -->
    <mxCell id="sysTitle" value="SYSTEM ACTORS" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=14;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="380" y="620" width="980" height="30" as="geometry" />
    </mxCell>

    <!-- Groq AI -->
    <mxCell id="groqBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="380" y="660" width="300" height="200" as="geometry" />
    </mxCell>
    <mxCell id="groqTitle" value="&lt;b&gt;GROQ AI SYSTEM&lt;/b&gt;&#xa;(External Automated Actor)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="380" y="670" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="groqActor" value="Groq AI" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
      <mxGeometry x="500" y="720" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="groqPerms" value="✓ Receive career chat messages&#xa;✓ Generate AI responses (LLaMA 3.3 70B)&#xa;✓ Generate career path documents&#xa;  Model: llama-3.3-70b-versatile" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="390" y="810" width="275" height="40" as="geometry" />
    </mxCell>

    <!-- Email System -->
    <mxCell id="emailBox" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;strokeWidth=2;" vertex="1" parent="1">
      <mxGeometry x="720" y="660" width="300" height="200" as="geometry" />
    </mxCell>
    <mxCell id="emailTitle" value="&lt;b&gt;EMAIL SYSTEM&lt;/b&gt;&#xa;(Nodemailer / Gmail SMTP)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="720" y="670" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="emailActor" value="Email&#xa;System" style="shape=mxgraph.flowchart.actor;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="840" y="720" width="60" height="80" as="geometry" />
    </mxCell>
    <mxCell id="emailPerms" value="✓ Send OTP verification email&#xa;✓ Send registration confirmation email&#xa;✓ Send password reset link&#xa;  Transport: Gmail SMTP (Nodemailer)" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="730" y="810" width="275" height="40" as="geometry" />
    </mxCell>

    <!-- LEGEND -->
    <mxCell id="legend" value="LEGEND" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;fontSize=12;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="60" y="660" width="280" height="30" as="geometry" />
    </mxCell>
    <mxCell id="leg1" value="✓ = Permitted Action" style="text;html=1;strokeColor=none;fillColor=#d5e8d4;align=left;verticalAlign=middle;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="60" y="700" width="200" height="30" as="geometry" />
    </mxCell>
    <mxCell id="leg2" value="✗ = Denied / Not Applicable" style="text;html=1;strokeColor=none;fillColor=#f8cecc;align=left;verticalAlign=middle;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="60" y="740" width="200" height="30" as="geometry" />
    </mxCell>
    <mxCell id="leg3" value="JWT verifyToken → all protected routes&#xa;requireAdmin → admin routes only" style="text;html=1;strokeColor=none;fillColor=#fff2cc;align=left;verticalAlign=middle;whiteSpace=wrap;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="60" y="790" width="280" height="50" as="geometry" />
    </mxCell>

  </root>
</mxGraphModel>
```

---

## Actor Diagram 2: Actor-Role Hierarchy — draw.io XML

```xml
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- TITLE -->
    <mxCell id="title" value="SMILE – Actor Role Hierarchy &amp; Authorization Flow" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=18;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="400" y="20" width="700" height="40" as="geometry" />
    </mxCell>

    <!-- TOP: Guest (base role) -->
    <mxCell id="guest" value="&lt;b&gt;GUEST&lt;/b&gt;&#xa;No authentication" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#999999;strokeWidth=2;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="600" y="100" width="200" height="60" as="geometry" />
    </mxCell>

    <!-- JWT Token Layer -->
    <mxCell id="jwt" value="🔐 JWT Token Issued&#xa;(HTTP-only Cookie)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;strokeWidth=2;fontSize=12;" vertex="1" parent="1">
      <mxGeometry x="600" y="220" width="200" height="60" as="geometry" />
    </mxCell>
    <mxCell id="e_gj" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#666666;" edge="1" source="guest" target="jwt" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>
    <mxCell id="e_gjl" value="Login / Register" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="e_gj"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- accountType fork -->
    <mxCell id="fork" value="accountType?" style="rhombus;whiteSpace=wrap;html=1;fillColor=#f0a30a;fontColor=#000000;strokeColor=#BD7000;strokeWidth=2;fontSize=13;" vertex="1" parent="1">
      <mxGeometry x="625" y="360" width="150" height="60" as="geometry" />
    </mxCell>
    <mxCell id="e_jf" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#d79b00;" edge="1" source="jwt" target="fork" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- STUDENT branch -->
    <mxCell id="stu" value="&lt;b&gt;STUDENT&lt;/b&gt;&#xa;accountType = student" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;strokeWidth=2;fontSize=12;" vertex="1" parent="1">
      <mxGeometry x="240" y="500" width="200" height="60" as="geometry" />
    </mxCell>
    <mxCell id="e_fs" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#6c8ebf;" edge="1" source="fork" target="stu" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="e_fsl" value="student" style="edgeLabel;html=1;align=center;verticalAlign=middle;" vertex="1" connectable="0" parent="e_fs"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- ORG branch (leads to admin check) -->
    <mxCell id="orgcheck" value="Admin DB check?" style="rhombus;whiteSpace=wrap;html=1;fillColor=#f0a30a;fontColor=#000000;strokeColor=#BD7000;strokeWidth=2;fontSize=12;" vertex="1" parent="1">
      <mxGeometry x="625" y="490" width="150" height="60" as="geometry" />
    </mxCell>
    <mxCell id="e_fo" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#82b366;" edge="1" source="fork" target="orgcheck" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="e_fol" value="organization" style="edgeLabel;html=1;align=center;verticalAlign=middle;" vertex="1" connectable="0" parent="e_fo"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- ADMIN branch -->
    <mxCell id="adm" value="&lt;b&gt;ADMIN&lt;/b&gt;&#xa;accountType = admin&#xa;requireAdmin middleware" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;strokeWidth=2;fontSize=12;" vertex="1" parent="1">
      <mxGeometry x="625" y="640" width="200" height="70" as="geometry" />
    </mxCell>
    <mxCell id="e_oa" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#b85450;" edge="1" source="orgcheck" target="adm" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="e_oal" value="found in Admin table" style="edgeLabel;html=1;align=center;verticalAlign=middle;" vertex="1" connectable="0" parent="e_oa"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- ORG approved branch -->
    <mxCell id="org" value="&lt;b&gt;ORGANISATION&lt;/b&gt;&#xa;accountType = organization&#xa;Status must be Active" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;strokeWidth=2;fontSize=12;" vertex="1" parent="1">
      <mxGeometry x="1000" y="490" width="220" height="70" as="geometry" />
    </mxCell>
    <mxCell id="e_on" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=2;strokeColor=#82b366;" edge="1" source="orgcheck" target="org" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="e_onl" value="not in Admin table" style="edgeLabel;html=1;align=center;verticalAlign=middle;" vertex="1" connectable="0" parent="e_on"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- STUDENT capabilities -->
    <mxCell id="stucap" value="Student Capabilities:&#xa;• Dashboard, Profile&#xa;• Browse &amp; Apply Opportunities&#xa;• Save Opportunities&#xa;• View Near Me (Map)&#xa;• RIASEC Quiz + AI Career Chat&#xa;• Generate &amp; Save Career Docs&#xa;• Read News &amp; Careers" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;align=left;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="80" y="640" width="280" height="160" as="geometry" />
    </mxCell>
    <mxCell id="e_ssc" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=1;strokeColor=#6c8ebf;dashed=1;" edge="1" source="stu" target="stucap" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- ORG capabilities -->
    <mxCell id="orgcap" value="Organisation Capabilities:&#xa;• Org Dashboard &amp; Analytics&#xa;• Create/Edit/Delete Opportunities&#xa;• View &amp; Manage Applicants&#xa;• Update Applicant Status&#xa;• View Dashboard Stats" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;align=left;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="1060" y="640" width="260" height="140" as="geometry" />
    </mxCell>
    <mxCell id="e_oc" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=1;strokeColor=#82b366;dashed=1;" edge="1" source="org" target="orgcap" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- ADMIN capabilities -->
    <mxCell id="admcap" value="Admin Capabilities:&#xa;• Admin Dashboard&#xa;• View All Orgs (with stats)&#xa;• Approve / Reject Orgs&#xa;• Delete Orgs &amp; Students&#xa;• View All Students" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;align=left;fontSize=11;" vertex="1" parent="1">
      <mxGeometry x="580" y="790" width="240" height="130" as="geometry" />
    </mxCell>
    <mxCell id="e_ac" style="edgeStyle=orthogonalEdgeStyle;html=1;strokeWidth=1;strokeColor=#b85450;dashed=1;" edge="1" source="adm" target="admcap" parent="1"><mxGeometry relative="1" as="geometry"/></mxCell>

  </root>
</mxGraphModel>
```

---

## Actor Responsibility Matrix

| Feature | Guest | Student | Organisation | Admin |
|---|:---:|:---:|:---:|:---:|
| View Home Page | ✅ | ✅ | ✅ | ✅ |
| Register | ✅ | — | — | — |
| Login | ✅ | ✅ | ✅ | ✅ |
| Forgot/Reset Password | ✅ | ✅ | ✅ | — |
| Student Dashboard | ❌ | ✅ | ❌ | ❌ |
| Update Student Profile | ❌ | ✅ | ❌ | ❌ |
| Browse Opportunities | ❌ | ✅ | ❌ | ❌ |
| Apply for Opportunity | ❌ | ✅ | ❌ | ❌ |
| Save Opportunity | ❌ | ✅ | ❌ | ❌ |
| View Near Me Map | ❌ | ✅ | ❌ | ❌ |
| Read News | ❌ | ✅ | ❌ | ❌ |
| Explore Careers | ❌ | ✅ | ❌ | ❌ |
| RIASEC Interest Quiz | ❌ | ✅ | ❌ | ❌ |
| AI Career Chatbot | ❌ | ✅ | ❌ | ❌ |
| Generate Career Docs | ❌ | ✅ | ❌ | ❌ |
| Org Dashboard | ❌ | ❌ | ✅ | ❌ |
| Create Opportunity | ❌ | ❌ | ✅ | ❌ |
| Edit/Delete Opportunity | ❌ | ❌ | ✅ | ❌ |
| View Applicants | ❌ | ❌ | ✅ | ❌ |
| Update Applicant Status | ❌ | ❌ | ✅ | ❌ |
| View Analytics | ❌ | ❌ | ✅ | ❌ |
| Admin Dashboard | ❌ | ❌ | ❌ | ✅ |
| Approve/Reject Org | ❌ | ❌ | ❌ | ✅ |
| Delete Organisation | ❌ | ❌ | ❌ | ✅ |
| Delete Student | ❌ | ❌ | ❌ | ✅ |
| Logout | ❌ | ✅ | ✅ | ✅ |
