# SMILE UI Icons — Inline SVG Pattern

## Why no icon library?

Modern production sites (Vercel, Linear, Notion, GitHub) stopped using icon fonts like Font Awesome years ago. The reasons:

- **Icon fonts** (Font Awesome, Bootstrap Icons) add 200–800 KB of network weight for glyphs you mostly don't use
- **Image sprites** (.png/.svg files) require extra HTTP requests and can't be styled with CSS
- **Inline SVG** costs nothing — it's just text baked into the HTML, zero extra requests

SMILE uses **100% inline SVG icons** drawn from the [Lucide](https://lucide.dev) icon set — the same icon system used by Vercel, shadcn/ui, and most modern design systems.

---

## How it works

Every icon is a small `<svg>` element written directly into HTML or into a JavaScript template literal. No library, no CDN, no import needed.

### Basic structure — every icon follows this pattern:

```html
<svg
  width="18"
  height="18"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <!-- shape goes here -->
  <path d="..."/>
</svg>
```

### The four key attributes explained:

| Attribute | Value | Why |
|---|---|---|
| `viewBox="0 0 24 24"` | Fixed coordinate grid | All Lucide icons use a 24×24 grid — keeps proportions consistent |
| `fill="none"` | No solid fill | Outline-only style, consistent with SMILE's clean UI |
| `stroke="currentColor"` | Inherits CSS text colour | Icon automatically matches button/link colour — hover states work for free |
| `stroke-width="2"` | Medium line weight | Balanced at small sizes; use `1.5` for large decorative icons |

---

## The magic: `stroke="currentColor"`

This one attribute is what makes inline SVG so powerful. The icon inherits whatever `color` CSS is set on its parent:

```html
<!-- Text is red → icon is also red, automatically -->
<a style="color: red;">
  <svg stroke="currentColor">...</svg>
  Delete
</a>

<!-- On hover the link turns orange → icon turns orange too -->
<a class="nav-link">  <!-- CSS: .nav-link:hover { color: #f97316 } -->
  <svg stroke="currentColor">...</svg>
  Dashboard
</a>
```

No extra CSS needed. No `.icon-color` utility class. It just works.

---

## How to use in HTML (static)

Copy the SVG from [lucide.dev](https://lucide.dev), paste it directly into the tag:

```html
<a href="/org/tickets" class="org-tab">
  <svg width="18" height="18" viewBox="0 0 24 24"
       fill="none" stroke="currentColor" stroke-width="2"
       stroke-linecap="round" stroke-linejoin="round">
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
    <line x1="4" y1="22" x2="4" y2="15"/>
  </svg>
  Report Issue
</a>
```

---

## How to use in JavaScript (dynamic DOM)

Inside a template literal — the SVG is just a string:

```js
tbody.innerHTML = tickets.map(t => `
  <tr>
    <td>
      <button onclick="openResolveModal(${t.TicketID})">
        <svg width="14" height="14" viewBox="0 0 24 24"
             fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        Resolve
      </button>
    </td>
  </tr>
`).join("");
```

---

## How SVG shapes are constructed

An AI (or a designer) can generate any icon from a description. The shapes are simple geometry:

| Shape | Used for |
|---|---|
| `<path d="..."/>` | Curved/complex shapes — arrows, logos, flags |
| `<line x1="" y1="" x2="" y2=""/>` | Straight lines — dividers, crosses |
| `<polyline points=""/>` | Connected straight lines — chevrons, checkmarks |
| `<circle cx="" cy="" r=""/>` | Circles — status dots, avatars |
| `<rect x="" y="" width="" height="" rx=""/>` | Boxes — cards, file icons |

### Example: generating a checkmark icon

```
Prompt to AI: "Give me a Lucide-style SVG checkmark icon, viewBox 0 0 24 24, stroke only"

Result:
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
  <polyline points="20 6 9 17 4 12"/>
</svg>
```

---

## Icons used in SMILE

| Location | Icon | Lucide name |
|---|---|---|
| Student dashboard nav | Bookmark | `bookmark` |
| Student dashboard nav | Clipboard | `clipboard-list` |
| Profile dropdown | Person | `user` |
| Profile dropdown | Tickets | `mail` (envelope) |
| Org sidebar | Bar chart | `bar-chart-2` |
| Org sidebar | Briefcase | `briefcase` |
| Org sidebar | Flag | `flag` |
| Admin tickets | Checkmark | `check` |
| Submit button | Send arrow | `send` |

All icons available at **https://lucide.dev/icons** — search, click, copy SVG.

---

## Why this is documented here

This is a **design system decision**, not just a style preference. Any developer adding a new page to SMILE should:

1. **Not** add a new icon library (`npm install react-icons`, `<link Font Awesome CDN>`, etc.)
2. **Not** create `.png` or `.svg` image files for UI icons
3. **Do** grab the SVG code from lucide.dev and paste it inline
4. **Do** always set `stroke="currentColor"` so it inherits parent colour automatically

This keeps every page's network payload minimal and keeps the icon style consistent across the whole product.
