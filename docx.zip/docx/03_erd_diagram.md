# SMILE Entity Relationship Diagram (ERD)

## Database: SMILE (MS SQL Server Express)

---

## ERD — draw.io XML

Copy and paste into draw.io (File → Extras → Edit Diagram).

```xml
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- TITLE -->
    <mxCell id="title" value="SMILE – Entity Relationship Diagram (ERD)" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=18;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="500" y="20" width="600" height="40" as="geometry" />
    </mxCell>

    <!-- ==================== STUDENT ==================== -->
    <mxCell id="student" value="Student" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="40" y="320" width="230" height="290" as="geometry" />
    </mxCell>
    <mxCell id="stu_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=1;" vertex="1" parent="student">
      <mxGeometry y="30" width="230" height="30" as="geometry" />
    </mxCell>
    <mxCell id="stu_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;top=0;left=0;bottom=0;right=0;fontStyle=1;overflow=hidden;" vertex="1" parent="stu_r0"><mxGeometry width="40" height="30" as="geometry"><mxRectangle width="40" height="30" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_pkv" value="StuID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;top=0;left=0;bottom=0;right=0;overflow=hidden;" vertex="1" parent="stu_r0"><mxGeometry x="40" width="190" height="30" as="geometry"><mxRectangle width="190" height="30" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="60" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r1l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;top=0;left=0;bottom=0;right=0;" vertex="1" parent="stu_r1"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r1v" value="StuName (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;top=0;left=0;bottom=0;right=0;overflow=hidden;" vertex="1" parent="stu_r1"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="85" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r2l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r2"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r2v" value="StuLastName (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r2"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="110" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r3l" value="UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="stu_r3"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r3v" value="StuEmail (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r3"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="135" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r4"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r4v" value="StuProvince (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r4"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="160" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r5"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r5v" value="StuEducationLevel (VARCHAR)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r5"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r6" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="185" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r6l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r6"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r6v" value="StuPassword (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r6"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r7" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="210" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r7l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r7"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r7v" value="StuBio (NVARCHAR MAX)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r7"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r8" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="235" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r8l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r8"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r8v" value="ProfilePicUrl (NVARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r8"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r9" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=0;" vertex="1" parent="student"><mxGeometry y="260" width="230" height="25" as="geometry"/></mxCell>
    <mxCell id="stu_r9l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="stu_r9"><mxGeometry width="40" height="25" as="geometry"><mxRectangle width="40" height="25" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="stu_r9v" value="DateCreated (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="stu_r9"><mxGeometry x="40" width="190" height="25" as="geometry"><mxRectangle width="190" height="25" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== ORGANISATION ==================== -->
    <mxCell id="org" value="Organisation" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="40" y="80" width="230" height="220" as="geometry" />
    </mxCell>
    <mxCell id="org_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=1;" vertex="1" parent="org"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="org_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="org_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_pkv" value="OrgId (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="org"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r1l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="org_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r1v" value="OrgName (VARCHAR 255) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="org"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r2l" value="UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="org_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r2v" value="OrgEmail (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="org"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="org_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r3v" value="Type (VARCHAR 255) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="org"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="org_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r4v" value="Province (VARCHAR 255) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="org"><mxGeometry y="154" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="org_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r5v" value="Password (VARCHAR 255) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r5"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r6" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="org"><mxGeometry y="178" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="org_r6l" value="CK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="org_r6"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="org_r6v" value="Status (Pending|Active|Rejected)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="org_r6"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== OPPORTUNITIES ==================== -->
    <mxCell id="opp" value="Opportunities" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
      <mxGeometry x="360" y="160" width="250" height="340" as="geometry" />
    </mxCell>
    <mxCell id="opp_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;fontSize=12;top=0;left=0;right=0;bottom=1;" vertex="1" parent="opp"><mxGeometry y="30" width="250" height="28" as="geometry"/></mxCell>
    <mxCell id="opp_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="opp_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_pkv" value="OppID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r0"><mxGeometry x="40" width="210" height="28" as="geometry"><mxRectangle width="210" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="opp"><mxGeometry y="58" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="opp_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r1v" value="OrgId → Organisation" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r1"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="82" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r2l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r2v" value="Title (VARCHAR 120) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r2"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="106" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r3v" value="OppType (VARCHAR 50) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r3"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="130" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r4v" value="Province (VARCHAR 50) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r4"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="154" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r5v" value="Description (VARCHAR MAX) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r5"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r6" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="178" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r6l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r6"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r6v" value="MaxApplicants (INT) NULL" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r6"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r7" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="202" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r7l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r7"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r7v" value="ApplicationDeadline (DATE) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r7"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r8" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="226" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r8l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r8"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r8v" value="Status (Active/Closed)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r8"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r9" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="250" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r9l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r9"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r9v" value="Lat (DECIMAL 9,6) | Lng (DECIMAL 9,6)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r9"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r10" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="opp"><mxGeometry y="274" width="250" height="24" as="geometry"/></mxCell>
    <mxCell id="opp_r10l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="opp_r10"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="opp_r10v" value="DateCreated (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="opp_r10"><mxGeometry x="40" width="210" height="24" as="geometry"><mxRectangle width="210" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== APPLICATIONS ==================== -->
    <mxCell id="app" value="Applications" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="700" y="280" width="230" height="180" as="geometry" />
    </mxCell>
    <mxCell id="app_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="app"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="app_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="app_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_pkv" value="AppID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="app"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="app_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="app_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r1v" value="OppID → Opportunities" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="app"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="app_r2l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="app_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r2v" value="StuID → Student" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="app"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="app_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="app_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r3v" value="Status (Pending/Shortlisted/Rejected)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="app"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="app_r4l" value="UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="app_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r4v" value="UNIQUE(OppID, StuID)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="app"><mxGeometry y="154" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="app_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="app_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="app_r5v" value="DateApplied (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="app_r5"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== FEEDBACK ==================== -->
    <mxCell id="fb" value="Feedback" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
      <mxGeometry x="700" y="490" width="230" height="180" as="geometry" />
    </mxCell>
    <mxCell id="fb_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="fb"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="fb_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="fb_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_pkv" value="FeedbackID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="fb"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="fb_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="fb_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r1v" value="OppID → Opportunities" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="fb"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="fb_r2l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="fb_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r2v" value="StuID → Student" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="fb"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="fb_r3l" value="CK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="fb_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r3v" value="Rating (INT 1-5)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="fb"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="fb_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="fb_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r4v" value="Comment (VARCHAR MAX)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="fb"><mxGeometry y="154" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="fb_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="fb_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="fb_r5v" value="DateSubmitted (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="fb_r5"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== STUDENT INTERESTS ==================== -->
    <mxCell id="si" value="StudentInterests" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="40" y="680" width="230" height="230" as="geometry" />
    </mxCell>
    <mxCell id="si_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="si"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="si_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="si_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_pkv" value="InterestID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="si"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r1l" value="FK/UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="si_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r1v" value="StuID → Student (UNIQUE)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="si"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r2l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="si_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r2v" value="Realistic (INT default 0)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="si"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="si_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r3v" value="Investigative / Artistic / Social" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="si"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="si_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r4v" value="Enterprising / Conventional" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="si"><mxGeometry y="154" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="si_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r5v" value="TopInterest (VARCHAR 50)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r5"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r6" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="si"><mxGeometry y="178" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="si_r6l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="si_r6"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="si_r6v" value="DateTaken (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="si_r6"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== SAVED CAREER DOCS ==================== -->
    <mxCell id="scd" value="SavedCareerDocs" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="360" y="550" width="240" height="170" as="geometry" />
    </mxCell>
    <mxCell id="scd_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="scd"><mxGeometry y="30" width="240" height="28" as="geometry"/></mxCell>
    <mxCell id="scd_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="scd_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_pkv" value="DocID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="scd_r0"><mxGeometry x="40" width="200" height="28" as="geometry"><mxRectangle width="200" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="scd"><mxGeometry y="58" width="240" height="24" as="geometry"/></mxCell>
    <mxCell id="scd_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="scd_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r1v" value="StuID → Student" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="scd_r1"><mxGeometry x="40" width="200" height="24" as="geometry"><mxRectangle width="200" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="scd"><mxGeometry y="82" width="240" height="24" as="geometry"/></mxCell>
    <mxCell id="scd_r2l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="scd_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r2v" value="CareerTitle (VARCHAR 100)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="scd_r2"><mxGeometry x="40" width="200" height="24" as="geometry"><mxRectangle width="200" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="scd"><mxGeometry y="106" width="240" height="24" as="geometry"/></mxCell>
    <mxCell id="scd_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="scd_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r3v" value="DocContent (NVARCHAR MAX)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="scd_r3"><mxGeometry x="40" width="200" height="24" as="geometry"><mxRectangle width="200" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="scd"><mxGeometry y="130" width="240" height="24" as="geometry"/></mxCell>
    <mxCell id="scd_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="scd_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="scd_r4v" value="DateSaved (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="scd_r4"><mxGeometry x="40" width="200" height="24" as="geometry"><mxRectangle width="200" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== SAVED OPPORTUNITIES ==================== -->
    <mxCell id="so" value="SavedOpportunities" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="700" y="700" width="230" height="170" as="geometry" />
    </mxCell>
    <mxCell id="so_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="so"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="so_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="so_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_pkv" value="SaveID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="so_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="so"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="so_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="so_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r1v" value="StuID → Student" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="so_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="so"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="so_r2l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="so_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r2v" value="OppID → Opportunities" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="so_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="so"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="so_r3l" value="UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="so_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r3v" value="UNIQUE(StuID, OppID)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="so_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="so"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="so_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="so_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="so_r4v" value="DateSaved (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="so_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== ADMIN ==================== -->
    <mxCell id="adm" value="Admin" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
      <mxGeometry x="1020" y="300" width="230" height="160" as="geometry" />
    </mxCell>
    <mxCell id="adm_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="adm"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="adm_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="adm_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_pkv" value="AdminID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="adm_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="adm"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="adm_r1l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="adm_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r1v" value="AdminName (VARCHAR 100) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="adm_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="adm"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="adm_r2l" value="UQ" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="adm_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r2v" value="AdminEmail (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="adm_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="adm"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="adm_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="adm_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r3v" value="AdminPassword (VARCHAR 255)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="adm_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="adm"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="adm_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="adm_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="adm_r4v" value="CreatedAt (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="adm_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== SUPPORT TICKETS ==================== -->
    <mxCell id="st" value="SupportTickets" style="shape=table;html=1;whiteSpace=wrap;startSize=30;container=1;collapsible=1;childLayout=tableLayout;fixedRows=1;rowLines=0;fontStyle=1;align=center;resizeLast=1;fontSize=14;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="1020" y="490" width="230" height="274" as="geometry" />
    </mxCell>
    <mxCell id="st_r0" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;top=0;left=0;right=0;bottom=1;" vertex="1" parent="st"><mxGeometry y="30" width="230" height="28" as="geometry"/></mxCell>
    <mxCell id="st_pk" value="PK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="st_r0"><mxGeometry width="40" height="28" as="geometry"><mxRectangle width="40" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_pkv" value="TicketID (INT IDENTITY)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r0"><mxGeometry x="40" width="190" height="28" as="geometry"><mxRectangle width="190" height="28" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r1" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;" vertex="1" parent="st"><mxGeometry y="58" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r1l" value="FK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=1;" vertex="1" parent="st_r1"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r1v" value="SubmitterID (INT) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r1"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r2" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="82" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r2l" value="CK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="st_r2"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r2v" value="SubmitterType (VARCHAR) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r2"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r3" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="106" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r3l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r3"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r3v" value="TicketType (VARCHAR) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r3"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r4" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="130" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r4l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r4"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r4v" value="Subject (VARCHAR 255) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r4"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r5" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="154" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r5l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r5"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r5v" value="Description (NVARCHAR MAX) NN" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r5"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r6" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="178" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r6l" value="CK" style="shape=partialRectangle;connectable=0;fillColor=none;fontStyle=2;" vertex="1" parent="st_r6"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r6v" value="Status (Open/Resolved)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r6"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r7" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="202" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r7l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r7"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r7v" value="AdminFeedback (NVARCHAR)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r7"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r8" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="226" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r8l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r8"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r8v" value="DateCreated (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r8"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r9" value="" style="shape=tableRow;horizontal=0;startSize=0;swimlaneHead=0;swimlaneBody=0;fillColor=none;collapsible=0;dropTarget=0;points=[[0,0.5],[1,0.5]];" vertex="1" parent="st"><mxGeometry y="250" width="230" height="24" as="geometry"/></mxCell>
    <mxCell id="st_r9l" value="" style="shape=partialRectangle;connectable=0;fillColor=none;" vertex="1" parent="st_r9"><mxGeometry width="40" height="24" as="geometry"><mxRectangle width="40" height="24" as="alternateBounds"/></mxGeometry></mxCell>
    <mxCell id="st_r9v" value="DateResolved (DATETIME)" style="shape=partialRectangle;connectable=0;fillColor=none;overflow=hidden;" vertex="1" parent="st_r9"><mxGeometry x="40" width="190" height="24" as="geometry"><mxRectangle width="190" height="24" as="alternateBounds"/></mxGeometry></mxCell>

    <!-- ==================== RELATIONSHIPS ==================== -->

    <!-- Organisation (1) → Opportunities (M) -->
    <mxCell id="rel1" value="1" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmanyToOne;exitX=1;exitY=0.5;entryX=0;entryY=0.5;html=1;strokeColor=#82b366;strokeWidth=2;" edge="1" source="org_r0" target="opp_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel1lbl" value="posts&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel1"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Opportunities (1) → Applications (M) -->
    <mxCell id="rel2" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.5;entryX=0;entryY=0.35;html=1;strokeColor=#b85450;strokeWidth=2;" edge="1" source="opp_r0" target="app_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel2lbl" value="has applications&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel2"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → Applications (M) -->
    <mxCell id="rel3" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.9;entryX=0;entryY=0.6;html=1;strokeColor=#b85450;strokeWidth=2;" edge="1" source="stu_r0" target="app_r2" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel3lbl" value="makes&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel3"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → StudentInterests (1:1) -->
    <mxCell id="rel4" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmandOne;startArrow=ERmandOne;exitX=0;exitY=0.5;entryX=1;entryY=0.35;html=1;strokeColor=#6c8ebf;strokeWidth=2;" edge="1" source="stu_r0" target="si_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel4lbl" value="has interests&#xa;(1:1)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel4"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → SavedCareerDocs (M) -->
    <mxCell id="rel5" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=0.5;exitY=1;entryX=0.5;entryY=0;html=1;strokeColor=#82b366;strokeWidth=2;" edge="1" source="stu_r0" target="scd_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel5lbl" value="saves docs&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel5"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Opportunities (1) → Feedback (M) -->
    <mxCell id="rel6" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.5;entryX=0;entryY=0.35;html=1;strokeColor=#9673a6;strokeWidth=2;" edge="1" source="opp_r0" target="fb_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel6lbl" value="receives feedback&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel6"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → Feedback (M) -->
    <mxCell id="rel7" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.9;entryX=0;entryY=0.6;html=1;strokeColor=#9673a6;strokeWidth=2;" edge="1" source="stu_r0" target="fb_r2" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel7lbl" value="gives feedback&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel7"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → SavedOpportunities (M) -->
    <mxCell id="rel8" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=1;entryX=0;entryY=0.35;html=1;strokeColor=#d79b00;strokeWidth=2;" edge="1" source="stu_r0" target="so_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel8lbl" value="saves opps&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel8"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Opportunities (1) → SavedOpportunities (M) -->
    <mxCell id="rel9" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=1;entryX=0;entryY=0.6;html=1;strokeColor=#d79b00;strokeWidth=2;" edge="1" source="opp_r0" target="so_r2" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel9lbl" value="saved in&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel9"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Student (1) → SupportTickets (M) -->
    <mxCell id="rel10" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.9;entryX=0;entryY=0.35;html=1;strokeColor=#dae8fc;strokeWidth=2;" edge="1" source="stu_r0" target="st_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel10lbl" value="submits tickets&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel10"><mxGeometry relative="1" as="geometry"/></mxCell>

    <!-- Organisation (1) → SupportTickets (M) -->
    <mxCell id="rel11" value="" style="edgeStyle=entityRelationEdgeStyle;endArrow=ERmanyToOne;startArrow=ERmandOne;exitX=1;exitY=0.9;entryX=0;entryY=0.6;html=1;strokeColor=#d5e8d4;strokeWidth=2;" edge="1" source="org_r0" target="st_r1" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="rel11lbl" value="submits tickets&#xa;(1:M)" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;" vertex="1" connectable="0" parent="rel11"><mxGeometry relative="1" as="geometry"/></mxCell>

  </root>
</mxGraphModel>

## ERD Summary Table

| Table | Rows | Key Relationships |
|---|---|---|
| **Student** | Core entity | 1:M Applications, 1:M Feedback, 1:1 StudentInterests, 1:M SavedCareerDocs, 1:M SavedOpportunities, 1:M SupportTickets |
| **Organisation** | Core entity | 1:M Opportunities, 1:M SupportTickets |
| **Opportunities** | Core entity | M:1 Organisation, 1:M Applications, 1:M Feedback, 1:M SavedOpportunities |
| **Applications** | Junction table | M:1 Student, M:1 Opportunities; UNIQUE(OppID, StuID) |
| **Feedback** | Weak entity | M:1 Student, M:1 Opportunities; Rating 1–5 CHECK |
| **StudentInterests** | Weak entity | 1:1 Student (UNIQUE StuID); RIASEC scores |
| **SavedCareerDocs** | Weak entity | M:1 Student |
| **SavedOpportunities** | Junction table | M:1 Student, M:1 Opportunities; UNIQUE(StuID, OppID) |
| **SupportTickets** | Weak entity | M:1 Student/Organisation (SubmitterID + SubmitterType); status flow |
| **Admin** | Standalone | No FKs; identified by JWT accountType="admin" |

## Constraints Summary

| Constraint | Type | Detail |
|---|---|---|
| `UQ_Student_Opp` | UNIQUE | Applications(OppID, StuID) — one app per student per opp |
| `UQ_Saved_Student_Opp` | UNIQUE | SavedOpportunities(StuID, OppID) |
| `CHK_OrgStatus` | CHECK | Organisation.Status IN ('Pending','Active','Rejected') |
| `CHK_Rating` | CHECK | Feedback.Rating BETWEEN 1 AND 5 |
| `CHK_TicketStatus` | CHECK | SupportTickets.Status IN ('Open', 'Resolved') |
| `CHK_SubmitterType` | CHECK | SupportTickets.SubmitterType IN ('student', 'org') |
| Cascade deletes | FK | Deleting Organisation cascades to Opportunities → Applications, Feedback, SavedOpportunities; Deleting Student cascades to Applications, Feedback, SavedOpportunities |
