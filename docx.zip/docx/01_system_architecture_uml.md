# SMILE System Architecture UML

## Overview
The SMILE platform follows a classic **3-Tier MVC Architecture** running on Node.js/Express with a Microsoft SQL Server backend.

---

## System Architecture Diagram — draw.io XML

Copy the XML below and paste it into draw.io (File → Extras → Edit Diagram).

```xml
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- TITLE -->
    <mxCell id="title" value="SMILE – System Architecture" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=18;fontStyle=1;" vertex="1" parent="1">
      <mxGeometry x="500" y="20" width="400" height="40" as="geometry" />
    </mxCell>

    <!-- ============ TIER 1: CLIENT (BROWSER) ============ -->
    <mxCell id="tier1" value="PRESENTATION TIER (Client Browser)" style="swimlane;fontStyle=1;fontSize=13;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
      <mxGeometry x="40" y="100" width="380" height="420" as="geometry" />
    </mxCell>
    <mxCell id="home" value="home.html&#xa;Landing Page" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="20" y="50" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="login" value="login.html&#xa;Login / Register" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="200" y="50" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="studash" value="studentdashboard.html&#xa;Student Dashboard" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="20" y="130" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="orgdash" value="orgdashboard.html&#xa;Org Dashboard" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="200" y="130" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="admindash" value="admin.html&#xa;Admin Dashboard" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="20" y="210" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="opps" value="nearme.html / news.html&#xa;careers.html / analytics" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="tier1">
      <mxGeometry x="200" y="210" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="jslayer" value="Frontend JS (jsFrontEnd/)&#xa;Fetch API calls to backend" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="tier1">
      <mxGeometry x="20" y="300" width="330" height="60" as="geometry" />
    </mxCell>
    <mxCell id="css" value="CSS Styling (css/)&#xa;Assets / Images" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="tier1">
      <mxGeometry x="20" y="380" width="330" height="30" as="geometry" />
    </mxCell>

    <!-- HTTP Arrow -->
    <mxCell id="arrow1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;strokeColor=#0066CC;strokeWidth=2;" edge="1" source="tier1" target="tier2" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="arrow1label" value="HTTP/HTTPS&#xa;REST API" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;points=[];" vertex="1" connectable="0" parent="arrow1">
      <mxGeometry x="-0.1" relative="1" as="geometry" />
    </mxCell>

    <!-- ============ TIER 2: APPLICATION SERVER ============ -->
    <mxCell id="tier2" value="APPLICATION TIER (Node.js / Express Server)" style="swimlane;fontStyle=1;fontSize=13;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
      <mxGeometry x="480" y="100" width="460" height="580" as="geometry" />
    </mxCell>
    <mxCell id="mainjs" value="main.js&#xa;Entry Point" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#82b366;fontColor=#ffffff;strokeColor=#82b366;" vertex="1" parent="tier2">
      <mxGeometry x="155" y="40" width="150" height="40" as="geometry" />
    </mxCell>
    <mxCell id="mw" value="Middleware&#xa;express.json | cookieParser | static" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="tier2">
      <mxGeometry x="80" y="110" width="300" height="40" as="geometry" />
    </mxCell>
    <mxCell id="routes" value="ROUTES" style="swimlane;fontStyle=1;fillColor=#f9f9f9;strokeColor=#82b366;" vertex="1" parent="tier2">
      <mxGeometry x="20" y="170" width="420" height="80" as="geometry" />
    </mxCell>
    <mxCell id="userroutes" value="userRoutes.js&#xa;(70+ endpoints)" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="routes">
      <mxGeometry x="30" y="25" width="155" height="40" as="geometry" />
    </mxCell>
    <mxCell id="adminroutes" value="adminRoute.js&#xa;(Admin endpoints)" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="routes">
      <mxGeometry x="230" y="25" width="155" height="40" as="geometry" />
    </mxCell>
    <mxCell id="controllers" value="CONTROLLERS" style="swimlane;fontStyle=1;fillColor=#f9f9f9;strokeColor=#82b366;" vertex="1" parent="tier2">
      <mxGeometry x="20" y="270" width="420" height="200" as="geometry" />
    </mxCell>
    <mxCell id="c1" value="userControllers.js&#xa;Register / Login" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="10" y="25" width="130" height="50" as="geometry" />
    </mxCell>
    <mxCell id="c2" value="sessionControllers.js&#xa;JWT verifyToken" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="150" y="25" width="130" height="50" as="geometry" />
    </mxCell>
    <mxCell id="c3" value="opportunitiesControllers.js&#xa;CRUD Opportunities" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="290" y="25" width="120" height="50" as="geometry" />
    </mxCell>
    <mxCell id="c4" value="studentController.js&#xa;Profile / Applications" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="10" y="90" width="130" height="50" as="geometry" />
    </mxCell>
    <mxCell id="c5" value="chatbotController.js&#xa;AI / Interests / Docs" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="150" y="90" width="130" height="50" as="geometry" />
    </mxCell>
    <mxCell id="c6" value="adminController.js&#xa;Org / Student CRUD" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="controllers">
      <mxGeometry x="290" y="90" width="120" height="50" as="geometry" />
    </mxCell>
    <mxCell id="extapis" value="EXTERNAL APIS" style="swimlane;fontStyle=1;fillColor=#f9f9f9;strokeColor=#82b366;" vertex="1" parent="tier2">
      <mxGeometry x="20" y="490" width="420" height="70" as="geometry" />
    </mxCell>
    <mxCell id="newsapi" value="newsAPI.js" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="extapis">
      <mxGeometry x="10" y="20" width="85" height="35" as="geometry" />
    </mxCell>
    <mxCell id="careersapi" value="careers.js" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="extapis">
      <mxGeometry x="105" y="20" width="85" height="35" as="geometry" />
    </mxCell>
    <mxCell id="booksapi" value="booksAPI.js" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="extapis">
      <mxGeometry x="200" y="20" width="85" height="35" as="geometry" />
    </mxCell>
    <mxCell id="geoapi" value="geoHelper.js" style="rounded=1;whiteSpace=wrap;html=1;" vertex="1" parent="extapis">
      <mxGeometry x="295" y="20" width="115" height="35" as="geometry" />
    </mxCell>

    <!-- Arrow to DB -->
    <mxCell id="arrow2" style="edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;strokeColor=#FF6600;strokeWidth=2;" edge="1" source="tier2" target="tier3" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="arrow2label" value="MSSQL (mssql pkg)&#xa;ODBC / Windows Auth" style="edgeLabel;html=1;align=center;verticalAlign=middle;resizable=0;points=[];" vertex="1" connectable="0" parent="arrow2">
      <mxGeometry x="-0.1" relative="1" as="geometry" />
    </mxCell>

    <!-- ============ TIER 3: DATA TIER ============ -->
    <mxCell id="tier3" value="DATA TIER (MS SQL Server Express – SMILE DB)" style="swimlane;fontStyle=1;fontSize=13;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
      <mxGeometry x="1020" y="100" width="360" height="580" as="geometry" />
    </mxCell>
    <mxCell id="dbconn" value="dbconnection.js&#xa;Connection Pool (ODBC Driver 18)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d79b00;fontColor=#ffffff;strokeColor=#d79b00;" vertex="1" parent="tier3">
      <mxGeometry x="60" y="40" width="240" height="50" as="geometry" />
    </mxCell>
    <mxCell id="t_student" value="[Student]&#xa;StuID, StuName, StuLastName,&#xa;StuEmail, StuProvince,&#xa;StuEducationLevel, StuPassword,&#xa;StuBio, ProfilePicUrl, DateCreated" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="10" y="120" width="165" height="100" as="geometry" />
    </mxCell>
    <mxCell id="t_org" value="[Organisation]&#xa;OrgId, OrgName, OrgEmail,&#xa;Type, Province, Password,&#xa;Status, DateCreated" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="185" y="120" width="165" height="100" as="geometry" />
    </mxCell>
    <mxCell id="t_opp" value="[Opportunities]&#xa;OppID, OrgId(FK),&#xa;Title, OppType, Province,&#xa;Description, Requirements,&#xa;MaxApplicants, Deadline,&#xa;StartDate, Status, Lat, Lng" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="10" y="240" width="165" height="110" as="geometry" />
    </mxCell>
    <mxCell id="t_app" value="[Applications]&#xa;AppID, OppID(FK),&#xa;StuID(FK), Status,&#xa;DateApplied" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="185" y="240" width="165" height="90" as="geometry" />
    </mxCell>
    <mxCell id="t_fb" value="[Feedback]&#xa;FeedbackID, OppID(FK),&#xa;StuID(FK), Rating,&#xa;Comment, DateSubmitted" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="10" y="370" width="165" height="90" as="geometry" />
    </mxCell>
    <mxCell id="t_si" value="[StudentInterests]&#xa;InterestID, StuID(FK),&#xa;RIASEC scores, TopInterest,&#xa;DateTaken" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="185" y="370" width="165" height="90" as="geometry" />
    </mxCell>
    <mxCell id="t_scd" value="[SavedCareerDocs]&#xa;DocID, StuID(FK),&#xa;CareerTitle, DocContent,&#xa;DateSaved" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="10" y="480" width="165" height="80" as="geometry" />
    </mxCell>
    <mxCell id="t_so" value="[SavedOpportunities]&#xa;SaveID, StuID(FK),&#xa;OppID(FK), DateSaved" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="185" y="480" width="165" height="80" as="geometry" />
    </mxCell>
    <mxCell id="t_admin" value="[Admin]&#xa;AdminID, AdminName,&#xa;AdminEmail, AdminPassword,&#xa;CreatedAt" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;align=left;" vertex="1" parent="tier3">
      <mxGeometry x="100" y="575" width="165" height="80" as="geometry" />
    </mxCell>

    <!-- ============ EXTERNAL SERVICES ============ -->
    <mxCell id="extsvcs" value="EXTERNAL SERVICES" style="swimlane;fontStyle=1;fontSize=12;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
      <mxGeometry x="480" y="720" width="460" height="160" as="geometry" />
    </mxCell>
    <mxCell id="groq" value="Groq AI API&#xa;(llama-3.3-70b)&#xa;Career Chatbot" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#9673a6;fontColor=#ffffff;strokeColor=#9673a6;" vertex="1" parent="extsvcs">
      <mxGeometry x="10" y="30" width="100" height="60" as="geometry" />
    </mxCell>
    <mxCell id="nodemailer" value="Nodemailer&#xa;(Gmail SMTP)&#xa;OTP / Notifications" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#9673a6;fontColor=#ffffff;strokeColor=#9673a6;" vertex="1" parent="extsvcs">
      <mxGeometry x="120" y="30" width="100" height="60" as="geometry" />
    </mxCell>
    <mxCell id="newsext" value="News API&#xa;(GNews / RSS)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#9673a6;fontColor=#ffffff;strokeColor=#9673a6;" vertex="1" parent="extsvcs">
      <mxGeometry x="230" y="30" width="100" height="60" as="geometry" />
    </mxCell>
    <mxCell id="jobitext" value="Job / Books API&#xa;(External)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#9673a6;fontColor=#ffffff;strokeColor=#9673a6;" vertex="1" parent="extsvcs">
      <mxGeometry x="340" y="30" width="100" height="60" as="geometry" />
    </mxCell>

  </root>
</mxGraphModel>
```

---

## Architecture Description

| Layer | Technology | Responsibility |
|---|---|---|
| Presentation | HTML5, Vanilla CSS, JS (Fetch API) | UI rendering, user interaction |
| Application | Node.js v20+, Express v5 | Business logic, routing, auth |
| Data | MS SQL Server Express (SMILE DB) | Persistent storage |
| Security | JWT (jsonwebtoken), bcrypt, HTTP-only cookies | Authentication & authorization |
| Email | Nodemailer + Gmail SMTP | OTP verification, registration emails |
| AI | Groq SDK (LLaMA 3.3 70B) | Career chatbot, document generation |
| External APIs | GNews/RSS, JSearch/Careers, Google Books | News, Jobs, Learning resources |
| Geo | geoHelper.js (Geocoding API) | Opportunity location coordinates |
